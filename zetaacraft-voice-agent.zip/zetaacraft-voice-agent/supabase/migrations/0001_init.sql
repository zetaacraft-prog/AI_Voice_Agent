-- Zetaacraft AI Voice Agent — initial schema
-- Every row is owned by an auth user; Row Level Security restricts access to the owner.
-- Telephone webhooks (no user session) use the service-role key server-side only.

create extension if not exists pgcrypto;

create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  phone text not null check (phone ~ '^\+[1-9][0-9]{6,14}$'),
  country text not null default '' check (country = '' or country ~ '^[A-Z]{2}$'),
  purpose text not null default '',
  consent_status text not null default 'pending' check (consent_status in ('granted','pending','denied','revoked')),
  consent_source text not null default '',
  consent_at timestamptz,
  notes text not null default '',
  status text not null default 'active' check (status in ('active','do_not_call','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint consent_granted_needs_source check (consent_status <> 'granted' or consent_source <> '')
);
create index if not exists contacts_owner_idx on public.contacts(owner_id);

create table if not exists public.call_sessions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  contact_id uuid references public.contacts(id) on delete set null,
  contact_name text,
  type text not null check (type in ('simulated','browser_voice','telephone')),
  status text not null check (status in ('queued','in_progress','completed','failed','no_answer','busy','canceled')),
  outcome text not null default '',
  provider text not null,
  provider_call_id text,
  language text not null default 'en' check (language in ('en','te','hi')),
  is_demo boolean not null default false,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  duration_sec integer not null default 0 check (duration_sec >= 0),
  error_message text,
  webhook_token_hash text
);
create index if not exists call_sessions_owner_started_idx on public.call_sessions(owner_id, started_at desc);
create unique index if not exists call_sessions_provider_call_idx on public.call_sessions(provider_call_id) where provider_call_id is not null;

create table if not exists public.transcript_entries (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  session_id uuid not null references public.call_sessions(id) on delete cascade,
  role text not null check (role in ('agent','user','system')),
  text text not null check (char_length(text) <= 4000),
  at timestamptz not null default now()
);
create index if not exists transcript_session_idx on public.transcript_entries(session_id, at);

create table if not exists public.app_settings (
  owner_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  default_language text not null default 'en' check (default_language in ('en','te','hi')),
  test_mode boolean not null default true,
  max_call_duration_sec integer not null default 300 check (max_call_duration_sec between 30 and 1800),
  agent_name text not null default 'Zara',
  disclosure_message text not null,
  store_transcripts boolean not null default true,
  transcript_retention_days integer not null default 30 check (transcript_retention_days between 1 and 365),
  updated_at timestamptz not null default now()
);

alter table public.contacts enable row level security;
alter table public.call_sessions enable row level security;
alter table public.transcript_entries enable row level security;
alter table public.app_settings enable row level security;

do $$
declare t text;
begin
  foreach t in array array['contacts','call_sessions','transcript_entries','app_settings'] loop
    execute format('drop policy if exists "%1$s_owner_all" on public.%1$s', t);
    execute format(
      'create policy "%1$s_owner_all" on public.%1$s for all to authenticated
         using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()))', t);
  end loop;
end $$;

-- The webhook token hash is only needed by the service role; hide it from clients.
-- (Column-level REVOKE has no effect while a table-level grant exists, so re-grant columns.)
revoke select on public.call_sessions from anon, authenticated;
grant select (id, owner_id, contact_id, contact_name, type, status, outcome, provider, provider_call_id,
              language, is_demo, started_at, ended_at, duration_sec, error_message)
  on public.call_sessions to authenticated;
revoke all on public.contacts, public.call_sessions, public.transcript_entries, public.app_settings from anon;
