# Zetaacraft AI Voice Agent — Trial MVP

A Next.js dashboard and voice agent that you can run **free, locally, with no accounts**, then upgrade step by step to a real AI voice model, a Supabase database with login, and (optionally) real, billed telephone calls through Twilio.

> **Free vs paid, plainly:** simulated calls and browser voice testing are free.
> Real AI voice (OpenAI Realtime) is billed by OpenAI per use. Real phone calls are billed per minute by Twilio, and international rates vary by destination.
> Nothing here provides free or unlimited international calling. A Claude or ChatGPT consumer subscription does **not** include API access.

## What works today

| Feature | Free demo mode (no keys) | With providers configured |
|---|---|---|
| Dashboard, contacts, call history, settings | ✅ in-memory store (persisted to `.data/` in dev) | ✅ Supabase Postgres + Auth + RLS |
| Simulated outbound calls | ✅ scripted, clearly labelled, never dials | ✅ same |
| Browser voice conversation | ✅ browser speech recognition/synthesis + **mock, rule-based** replies (labelled "Demo – mock AI") | ✅ OpenAI Realtime over WebRTC (real AI speech-to-speech) |
| Live transcript, mute, voice activity, max duration | ✅ | ✅ |
| Real telephone calls | ❌ always blocked | ✅ Twilio, behind 18 safety checks |
| Languages | English | English. Telugu and Hindi are set up in the code but switched off (see `docs/ARCHITECTURE.md`) |

## Quick start (free demo mode)

```bash
npm install
cp .env.example .env.local     # optional in demo mode
npm run dev                    # http://localhost:3000
```

You can then:
1. **Contacts → Simulate** on a sample contact. Pick a scenario (interested, callback, no answer, opt-out, …).
2. **Voice agent → Start conversation**. Allow the microphone and speak. Use Chrome or Edge for speech recognition, or type messages in any browser.
3. **Call history → Details → Show transcript**.

## Commands

```bash
npm run dev         # dev server
npm run check       # typecheck + lint + unit/API tests
npm test            # Vitest (safety gate, validation, API routes, webhooks)
npm run test:e2e    # Playwright (builds and starts the app in demo mode on :3100)
npm run build       # production build
```

## Upgrading, step by step

There's also an in-app guide at `/setup`, and the dashboard shows the live config status.

### 1. Supabase (database + login)
1. Create a Supabase project and run `supabase/migrations/0001_init.sql` in the SQL editor.
2. Set `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` (the anon key also works), and `SUPABASE_SERVICE_ROLE_KEY`. The service-role key is server-only and is used only by the telephone webhooks.
3. Restart. You'll be redirected to `/login`. Every table has Row Level Security that limits each user to their own rows.

### 2. Real AI voice (OpenAI Realtime)
```
AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_REALTIME_MODEL=gpt-realtime
```
The server creates a **120-second client secret** (`POST /v1/realtime/client_secrets`). The browser then connects directly to OpenAI over WebRTC (`POST /v1/realtime/calls`). Your API key never reaches the browser.

### 3. Real phone calls (optional, paid)
Twilio must have a valid caller ID: either a Twilio number you own, or **your own number added as a Verified Caller ID**. The app checks this with the Twilio API before every call.

```
LIVE_CALLS_ENABLED=true
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_CALLER_ID=+91XXXXXXXXXX
LIVE_CALL_ALLOWED_COUNTRIES=IN,US
APP_BASE_URL=https://<public https URL>   # Vercel URL, or `ngrok http 3000` locally
```
Also turn on the destination countries in Twilio Console → Voice → Geo permissions. Twilio **trial** accounts can only call verified numbers and play a trial notice.

Then switch **Test mode** off in Settings. A real call is placed only when **all** of these hold:

- the server kill switch `LIVE_CALLS_ENABLED=true` is set
- the app is in Supabase mode and the user is signed in
- test mode is off
- Twilio is configured and the caller ID is verified with Twilio
- the service-role key is set for webhooks
- `APP_BASE_URL` is https
- a disclosure message is set
- the contact's consent is `granted` and its source is recorded
- the contact is active and not on the do-not-call list
- the number is valid E.164 and its country is on the allow-list
- the user typed the last 4 digits and confirmed the charges
- the hourly limit has not been reached

All of this lives in one pure function, `src/lib/safety/live-call-gate.ts`, with exhaustive tests.

During a call, Twilio plays the AI disclosure and then runs a speech `<Gather>` loop. Each turn goes to the AI provider (Responses API), or to mock replies if no AI is configured. If the callee says "stop" or "don't call", the call ends and the contact is marked do-not-call. Webhooks are verified with the `X-Twilio-Signature` header **and** a per-call secret token, which is stored hashed.

## Architecture

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for request flows, the provider interfaces, and how to add Telugu/Hindi or a streaming telephone service.

```
src/
  app/(dashboard)/        Overview, Contacts, Voice agent, Call history, Settings (client pages)
  app/api/                JSON API (Zod-validated) + Twilio webhooks
  app/login, app/setup    Supabase sign-in, setup guide
  proxy.ts                Supabase session refresh + auth redirect (Next 16 "proxy", formerly middleware)
  lib/safety/             Live-call safety gate (pure, tested)
  lib/ai/                 AI provider interface: demo (mock) + OpenAI
  lib/telecom/            Telecom provider interface: simulated + Twilio; webhook verification
  lib/data/               Repository interface: memory (demo) + Supabase (RLS) + webhook (service role)
  lib/client/             Browser voice engines (WebRTC realtime, demo speech), fetch helpers
supabase/migrations/      SQL schema + RLS policies
tests/unit, tests/e2e     Vitest, Playwright
```

## Deploying to Vercel
1. Import the repository into Vercel and add the environment variables (don't use the `NEXT_PUBLIC_` prefix for any secret).
2. Set `APP_BASE_URL` to the production URL.
3. **Configure Supabase before sharing the URL.** Demo data mode has no login, and the app shows a warning banner when it runs in production without Supabase.
4. Twilio webhooks (`/api/telephony/twilio/*`) are ordinary serverless functions, so the current `<Gather>`-based phone flow runs on Vercel as-is.
5. **Real-time streaming audio on phone calls** (Twilio Media Streams ↔ a speech-to-speech model) needs a long-lived WebSocket server, which Vercel functions don't provide. That is a separate service. See `docs/ARCHITECTURE.md` → "Phase 2".

## Security notes
- Secrets are only read in `server-only` modules (`src/lib/env.ts`). `/api/status` returns only booleans and a masked caller ID, and a test checks this.
- All API input is validated with Zod. Errors never return stack traces.
- Security headers (CSP, frame-ancestors none, nosniff, and a Permissions-Policy that allows the microphone only for this site) are set in `next.config.ts`.
- The rate limits are in-memory, so each server instance counts separately. Use a shared store such as Upstash Redis when running more than one instance.
- Phone numbers are masked in lists and revealed one at a time on click. Transcripts load only on an explicit click and are purged after the retention period.

## Not verified in this environment
The OpenAI and Twilio documentation sites couldn't be reached from the build sandbox. API shapes were checked against the type definitions in the installed official SDKs (`openai@7`, `twilio@6`) instead. Real OpenAI and Twilio calls have **not** been run end-to-end because no credentials were available. Run a test with your own accounts, starting with a Twilio trial and your own verified number.
