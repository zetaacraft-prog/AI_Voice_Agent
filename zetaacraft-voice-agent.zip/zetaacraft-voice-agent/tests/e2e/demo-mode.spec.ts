import { expect, test } from "@playwright/test";

test.describe("free demo mode", () => {
  test("dashboard loads without any accounts and shows TEST MODE", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("heading", { name: "Overview" })).toBeVisible();
    await expect(page.getByTestId("mode-banner")).toContainText("TEST MODE");
    await expect(page.getByTestId("mode-banner")).toContainText("Mock AI responses");
    await expect(page.getByTestId("stat-mode")).toContainText("Test");
  });

  test("add a contact with validation errors, then successfully", async ({ page }) => {
    await page.goto("/contacts");
    await page.getByRole("button", { name: "+ Add contact" }).click();
    const dialog = page.getByRole("dialog", { name: "Add contact" });
    await dialog.getByLabel("Name").fill("E2E Tester");
    await dialog.getByLabel("Phone (with country code)").fill("98765");
    await dialog.getByRole("button", { name: "Add contact" }).click();
    await expect(dialog.getByText(/valid number with country code/)).toBeVisible();

    await dialog.getByLabel("Phone (with country code)").fill("+44 20 7946 0958");
    await dialog.getByRole("button", { name: "Add contact" }).click();
    await expect(dialog).toBeHidden();
    const row = page.getByTestId("contact-row").filter({ hasText: "E2E Tester" });
    await expect(row).toContainText("GB");
    await expect(row).toContainText("+44 ••••••0958");
  });

  test("simulated call runs, is labelled simulated and appears in history with transcript", async ({ page }) => {
    await page.goto("/contacts");
    const row = page.getByTestId("contact-row").filter({ hasText: "Ananya Rao" });
    await row.getByRole("button", { name: "Simulate" }).click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toContainText("Nothing is dialed");
    await dialog.getByLabel("Scenario").selectOption("interested");
    await dialog.getByRole("button", { name: "Start simulated call" }).click();
    await expect(dialog.getByTestId("sim-transcript")).toContainText("SIMULATED CALL");
    await expect(dialog.getByTestId("sim-result")).toContainText("Interested", { timeout: 15_000 });

    await page.goto("/history");
    const hist = page.getByTestId("history-row").filter({ hasText: "Ananya Rao" }).first();
    await expect(hist).toContainText("Simulated");
    await expect(hist).toContainText("completed");
    await hist.getByRole("button", { name: "Details" }).click();
    await page.getByTestId("reveal-transcript").click();
    await expect(page.getByTestId("history-transcript")).toContainText("Contact (simulated)");
    await expect(page.getByText("Simulated — no real phone was dialed.")).toBeVisible();
  });

  test("live call is blocked with clear reasons in test mode", async ({ page }) => {
    await page.goto("/contacts");
    const row = page.getByTestId("contact-row").filter({ hasText: "Ananya Rao" });
    await row.getByRole("button", { name: "Live call" }).click();
    const reasons = page.getByTestId("gate-reasons");
    await expect(reasons).toContainText("TEST_MODE");
    await expect(reasons).toContainText("SERVER_KILL_SWITCH");
    await expect(page.getByRole("button", { name: "Place real call" })).toHaveCount(0);
  });

  test("settings: test mode is locked on and providers show as not configured", async ({ page }) => {
    await page.goto("/settings");
    await expect(page.getByTestId("test-mode-toggle")).toBeChecked();
    await expect(page.getByTestId("test-mode-toggle")).toBeDisabled();
    await expect(page.getByTestId("test-mode-locked")).toBeVisible();
    await expect(page.getByText("Not configured — demo mock responses")).toBeVisible();
    await page.getByLabel("Maximum call duration (seconds)").fill("120");
    await page.getByRole("button", { name: "Save settings" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
  });

  test("voice agent: demo notice and typed conversation with mock AI", async ({ page, context, browserName }) => {
    test.skip(browserName !== "chromium", "fake media device flags are Chromium-only");
    await context.grantPermissions(["microphone"]);
    await page.goto("/agent");
    await expect(page.getByTestId("demo-voice-notice")).toContainText("mock, rule-based responses");
    await page.getByTestId("start-voice").click();
    await expect(page.getByTestId("voice-state")).toContainText("Live", { timeout: 15_000 });
    await expect(page.getByTestId("live-transcript")).toContainText("AI voice assistant from Zetaacraft");
    await page.getByLabel("Type a message").fill("What is your pricing?");
    await page.getByRole("button", { name: "Send" }).click();
    await expect(page.getByTestId("live-transcript")).toContainText("Pricing depends on your needs");
    await page.getByTestId("stop-voice").click();
    await expect(page.getByTestId("voice-state")).toContainText("Not connected");

    await page.goto("/history");
    await expect(page.getByTestId("history-row").first()).toContainText("Browser voice · demo");
  });

  test("setup guide is reachable and explains paid vs free", async ({ page }) => {
    await page.goto("/setup");
    await expect(page.getByRole("heading", { name: "Setup guide" })).toBeVisible();
    await expect(page.getByText(/billed per minute/)).toBeVisible();
  });
});
