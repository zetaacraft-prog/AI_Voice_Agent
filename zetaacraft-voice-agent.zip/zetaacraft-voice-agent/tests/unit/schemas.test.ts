import { describe, expect, it } from "vitest";
import { contactInputSchema, settingsSchema, liveCallSchema } from "@/lib/schemas";
import { DEFAULT_SETTINGS } from "@/lib/defaults";
import { maskPhone, parsePhone } from "@/lib/phone";

describe("contact validation", () => {
  it("normalises phone to E.164 and detects country", () => {
    const r = contactInputSchema.parse({ name: " Ravi ", phone: "+91 98765-43210" });
    expect(r).toMatchObject({ name: "Ravi", phone: "+919876543210", country: "IN", consentStatus: "pending", status: "active" });
  });

  it("rejects numbers without a country code", () => {
    const r = contactInputSchema.safeParse({ name: "A", phone: "9876543210" });
    expect(r.success).toBe(false);
    expect(r.error?.issues[0].path).toEqual(["phone"]);
  });

  it("requires a consent source when consent is granted", () => {
    const r = contactInputSchema.safeParse({ name: "A", phone: "+12025550143", consentStatus: "granted" });
    expect(r.success).toBe(false);
    expect(r.error?.issues[0].path).toEqual(["consentSource"]);
  });

  it("rejects a country that contradicts the number", () => {
    const r = contactInputSchema.safeParse({ name: "A", phone: "+919876543210", country: "US" });
    expect(r.success).toBe(false);
  });

  it("caps field lengths", () => {
    expect(contactInputSchema.safeParse({ name: "x".repeat(121), phone: "+919876543210" }).success).toBe(false);
  });
});

describe("settings validation", () => {
  it("accepts defaults", () => {
    expect(settingsSchema.parse(DEFAULT_SETTINGS)).toEqual(DEFAULT_SETTINGS);
  });
  it("bounds max call duration", () => {
    expect(settingsSchema.safeParse({ ...DEFAULT_SETTINGS, maxCallDurationSec: 5 }).success).toBe(false);
    expect(settingsSchema.safeParse({ ...DEFAULT_SETTINGS, maxCallDurationSec: 99999 }).success).toBe(false);
  });
});

describe("live call request", () => {
  it("requires explicit charge acknowledgement and 4 digits", () => {
    const id = "6f1c1d3e-1b2a-4c5d-8e9f-000000000001";
    expect(liveCallSchema.safeParse({ contactId: id, confirmLast4: "1234", acknowledgedCharges: false }).success).toBe(false);
    expect(liveCallSchema.safeParse({ contactId: id, confirmLast4: "12", acknowledgedCharges: true }).success).toBe(false);
    expect(liveCallSchema.safeParse({ contactId: id, confirmLast4: "1234", acknowledgedCharges: true }).success).toBe(true);
  });
});

describe("phone helpers", () => {
  it("parses and masks", () => {
    expect(parsePhone("+1 202 555 0143")).toEqual({ e164: "+12025550143", country: "US" });
    expect(parsePhone("not a number")).toBeNull();
    expect(maskPhone("+919876543210")).toBe("+91 ••••••3210");
  });
});
