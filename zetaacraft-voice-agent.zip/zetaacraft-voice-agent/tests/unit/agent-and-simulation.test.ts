import { describe, expect, it } from "vitest";
import { mockAgentReply } from "@/lib/ai/mock-agent";
import { buildAgentInstructions, isOptOut } from "@/lib/ai/agent-prompt";
import { buildSimulatedCall, pickScenario } from "@/lib/simulation/simulated-call";
import { computeMetrics } from "@/lib/metrics";
import { DEFAULT_SETTINGS } from "@/lib/defaults";
import { resolveLanguage } from "@/lib/languages";
import type { CallSession } from "@/lib/types";

describe("mock agent (demo only)", () => {
  it("ends the conversation on opt-out", () => {
    expect(mockAgentReply("please stop calling me")).toMatchObject({ endConversation: true });
    expect(isOptOut("Don't call me again")).toBe(true);
    expect(isOptOut("I'd love to hear more")).toBe(false);
  });
  it("admits to being an AI", () => {
    expect(mockAgentReply("are you a human?").text).toMatch(/AI/);
  });
  it("always returns a reply", () => {
    expect(mockAgentReply("hmm").text.length).toBeGreaterThan(0);
  });
});

describe("agent instructions", () => {
  it("include AI disclosure rule and opt-out handling", () => {
    const s = buildAgentInstructions({ settings: DEFAULT_SETTINGS, language: "en", channel: "telephone" });
    expect(s).toMatch(/Never claim to be human/);
    expect(s).toMatch(/opt out/);
    expect(s).toContain(DEFAULT_SETTINGS.disclosureMessage);
  });
});

describe("languages", () => {
  it("falls back to English for planned languages", () => {
    expect(resolveLanguage("te").code).toBe("en");
    expect(resolveLanguage("hi").code).toBe("en");
    expect(resolveLanguage(undefined).code).toBe("en");
  });
});

describe("simulated calls", () => {
  const contact = { name: "Ravi Kumar", purpose: "demo follow-up" };
  it("labels every simulation as simulated in the first line", () => {
    for (const sc of ["interested", "callback", "not_interested", "no_answer", "opt_out"] as const) {
      const r = buildSimulatedCall(contact, DEFAULT_SETTINGS, sc);
      expect(r.lines[0]).toMatchObject({ role: "system" });
      expect(r.lines[0].text).toMatch(/SIMULATED/);
      expect(r.outcome).toMatch(/simulated/i);
    }
  });
  it("opens with the AI disclosure", () => {
    const r = buildSimulatedCall(contact, DEFAULT_SETTINGS, "interested");
    expect(r.lines[1]).toMatchObject({ role: "agent", text: DEFAULT_SETTINGS.disclosureMessage });
  });
  it("marks do-not-call on opt-out", () => {
    expect(buildSimulatedCall(contact, DEFAULT_SETTINGS, "opt_out").markDoNotCall).toBe(true);
  });
  it("respects max duration", () => {
    const r = buildSimulatedCall(contact, { ...DEFAULT_SETTINGS, maxCallDurationSec: 30 }, "interested");
    expect(r.durationSec).toBeLessThanOrEqual(30);
  });
  it("no-answer has zero duration", () => {
    expect(buildSimulatedCall(contact, DEFAULT_SETTINGS, "no_answer")).toMatchObject({ status: "no_answer", durationSec: 0 });
  });
  it("picks scenarios deterministically", () => {
    expect(pickScenario("abc")).toBe(pickScenario("abc"));
  });
});

describe("metrics", () => {
  it("aggregates sessions", () => {
    const base = { id: "x", contactId: null, contactName: null, outcome: "", provider: "demo", providerCallId: null, language: "en", isDemo: true, startedAt: "", endedAt: null, errorMessage: null } as const;
    const sessions: CallSession[] = [
      { ...base, type: "simulated", status: "completed", durationSec: 30 },
      { ...base, type: "browser_voice", status: "failed", durationSec: 5 },
      { ...base, type: "telephone", status: "completed", durationSec: 60, isDemo: false },
    ];
    expect(computeMetrics(sessions)).toEqual({
      totalTestSessions: 2,
      completedCalls: 2,
      failedSessions: 1,
      totalDurationSec: 95,
      byType: { simulated: 1, browser_voice: 1, telephone: 1 },
    });
  });
});
