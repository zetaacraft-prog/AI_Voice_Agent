import { beforeEach, describe, expect, it, vi } from "vitest";
import twilio from "twilio";

// Spy on the real-network telecom provider: it must never be reached in these tests.
const placeCall = vi.fn();
const verifyCallerId = vi.fn(async () => ({ ok: true, kind: "provider_number", message: "" }));
vi.mock("@/lib/telecom", () => ({
  getLiveTelecomProvider: () => ({ id: "twilio", realNetwork: true, placeCall, verifyCallerId }),
}));

const SAMPLE_GRANTED = "6f1c1d3e-1b2a-4c5d-8e9f-000000000001"; // seeded, consent granted, IN

function json(url: string, body: unknown, method = "POST") {
  return new Request(`http://localhost:3000${url}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

beforeEach(async () => {
  vi.unstubAllEnvs();
  // Demo data mode, but with every live-call env var "configured" to prove test mode still blocks.
  vi.stubEnv("NEXT_PUBLIC_SUPABASE_URL", "");
  vi.stubEnv("NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY", "");
  vi.stubEnv("LIVE_CALLS_ENABLED", "true");
  vi.stubEnv("TWILIO_ACCOUNT_SID", "AC" + "a".repeat(32));
  vi.stubEnv("TWILIO_AUTH_TOKEN", "b".repeat(32));
  vi.stubEnv("TWILIO_CALLER_ID", "+12025550100");
  vi.stubEnv("APP_BASE_URL", "https://example.com");
  vi.stubEnv("LIVE_CALL_ALLOWED_COUNTRIES", "IN,US");
  vi.stubEnv("SUPABASE_SERVICE_ROLE_KEY", "x");
  placeCall.mockReset();
  const { resetDemoState } = await import("@/lib/data/memory-store");
  resetDemoState();
});

describe("POST /api/calls/live", () => {
  it("is blocked in demo/test mode and never reaches the telecom provider", async () => {
    const { POST } = await import("@/app/api/calls/live/route");
    const res = await POST(json("/api/calls/live", { contactId: SAMPLE_GRANTED, confirmLast4: "0001", acknowledgedCharges: true }));
    expect(res.status).toBe(403);
    const body = await res.json();
    const codes = body.reasons.map((r: { code: string }) => r.code);
    expect(codes).toContain("TEST_MODE");
    expect(codes).toContain("DEMO_DATA_MODE");
    expect(placeCall).not.toHaveBeenCalled();
    expect(verifyCallerId).not.toHaveBeenCalled();
  });

  it("rejects malformed requests before any processing", async () => {
    const { POST } = await import("@/app/api/calls/live/route");
    const res = await POST(json("/api/calls/live", { contactId: SAMPLE_GRANTED }));
    expect(res.status).toBe(400);
    expect(placeCall).not.toHaveBeenCalled();
  });
});

describe("PUT /api/settings", () => {
  it("refuses to turn test mode off in demo data mode", async () => {
    const { PUT } = await import("@/app/api/settings/route");
    const res = await PUT(json("/api/settings", { testMode: false }, "PUT"));
    expect(res.status).toBe(409);
  });

  it("refuses planned-but-unavailable languages", async () => {
    const { PUT } = await import("@/app/api/settings/route");
    const res = await PUT(json("/api/settings", { defaultLanguage: "te" }, "PUT"));
    expect(res.status).toBe(400);
  });
});

describe("POST /api/calls/simulate", () => {
  it("creates a simulated session without dialing", async () => {
    const { POST } = await import("@/app/api/calls/simulate/route");
    const res = await POST(json("/api/calls/simulate", { contactId: SAMPLE_GRANTED, scenario: "interested" }));
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.session).toMatchObject({ type: "simulated", status: "completed", isDemo: true, provider: "simulated" });
    expect(body.session.providerCallId).toMatch(/^SIM-/);
    expect(placeCall).not.toHaveBeenCalled();
  });

  it("opt-out scenario marks the contact do-not-call", async () => {
    const { POST } = await import("@/app/api/calls/simulate/route");
    await POST(json("/api/calls/simulate", { contactId: SAMPLE_GRANTED, scenario: "opt_out" }));
    const { GET } = await import("@/app/api/contacts/[id]/route");
    const res = await GET(new Request("http://localhost/x"), { params: Promise.resolve({ id: SAMPLE_GRANTED }) });
    expect((await res.json()).contact).toMatchObject({ status: "do_not_call", consentStatus: "revoked" });
  });
});

describe("GET /api/status", () => {
  it("never exposes secrets", async () => {
    vi.stubEnv("OPENAI_API_KEY", "sk-supersecretvalue");
    vi.stubEnv("AI_PROVIDER", "openai");
    const { GET } = await import("@/app/api/status/route");
    const text = await (await GET()).text();
    expect(text).not.toContain("sk-supersecretvalue");
    expect(text).not.toContain("b".repeat(32));
    expect(text).not.toContain("+12025550100");
    expect(JSON.parse(text).telecom.callerIdMasked).toBe("••••0100");
  });
});

describe("contacts API", () => {
  it("validates and creates a contact", async () => {
    const { POST } = await import("@/app/api/contacts/route");
    const bad = await POST(json("/api/contacts", { name: "", phone: "123" }));
    expect(bad.status).toBe(400);
    const ok = await POST(json("/api/contacts", { name: "Test", phone: "+44 20 7946 0958" }));
    expect(ok.status).toBe(201);
    expect((await ok.json()).contact).toMatchObject({ phone: "+442079460958", country: "GB" });
  });
});

describe("Twilio webhooks", () => {
  it("reject requests without a valid signature", async () => {
    const { POST } = await import("@/app/api/telephony/twilio/voice/route");
    const req = new Request("https://example.com/api/telephony/twilio/voice?session=x&token=y", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", "X-Twilio-Signature": "forged" },
      body: new URLSearchParams({ CallSid: "CA123", CallStatus: "in-progress" }),
    });
    expect((await POST(req)).status).toBe(403);
  });

  it("with a valid signature still require a matching session token", async () => {
    const url = "https://example.com/api/telephony/twilio/status?session=x&token=y";
    const params = { CallSid: "CA123", CallStatus: "completed" };
    const sig = twilio.getExpectedTwilioSignature("b".repeat(32), url, params);
    const { POST } = await import("@/app/api/telephony/twilio/status/route");
    const req = new Request(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", "X-Twilio-Signature": sig },
      body: new URLSearchParams(params),
    });
    expect((await POST(req)).status).toBe(404);
  });
});
