import { describe, expect, it } from "vitest";
import { evaluateLiveCallGate, type LiveCallGateInput } from "@/lib/safety/live-call-gate";

const passing = (): LiveCallGateInput => ({
  server: {
    liveCallsEnabled: true,
    supabaseMode: true,
    telecomConfigured: true,
    webhookServiceRoleConfigured: true,
    appBaseUrl: "https://example.com",
    allowedCountries: ["IN", "US"],
    maxLiveCallsPerHour: 10,
  },
  user: { authenticated: true, liveCallsInLastHour: 0 },
  settings: { testMode: false, disclosureMessage: "Hi, this is an AI assistant from Zetaacraft." },
  contact: { phone: "+919876543210", country: "IN", consentStatus: "granted", consentSource: "Web form", status: "active" },
  confirmation: { confirmLast4: "3210", acknowledgedCharges: true },
});

const codes = (i: LiveCallGateInput) => evaluateLiveCallGate(i).reasons.map((r) => r.code);

describe("live call safety gate", () => {
  it("allows a call only when every requirement is met", () => {
    expect(evaluateLiveCallGate(passing())).toEqual({ allowed: true, reasons: [] });
  });

  it("ALWAYS blocks in test mode, even when everything else is configured", () => {
    const i = passing();
    i.settings.testMode = true;
    const r = evaluateLiveCallGate(i);
    expect(r.allowed).toBe(false);
    expect(r.reasons.map((x) => x.code)).toEqual(["TEST_MODE"]);
  });

  it("treats a missing/undefined testMode as test mode (fail closed)", () => {
    const i = passing();
    (i.settings as { testMode?: boolean }).testMode = undefined;
    expect(codes(i)).toContain("TEST_MODE");
  });

  it.each([
    ["SERVER_KILL_SWITCH", (i: LiveCallGateInput) => (i.server.liveCallsEnabled = false)],
    ["DEMO_DATA_MODE", (i: LiveCallGateInput) => (i.server.supabaseMode = false)],
    ["NOT_AUTHENTICATED", (i: LiveCallGateInput) => (i.user.authenticated = false)],
    ["TELECOM_NOT_CONFIGURED", (i: LiveCallGateInput) => (i.server.telecomConfigured = false)],
    ["WEBHOOK_STORE_NOT_CONFIGURED", (i: LiveCallGateInput) => (i.server.webhookServiceRoleConfigured = false)],
    ["WEBHOOK_URL_NOT_HTTPS", (i: LiveCallGateInput) => (i.server.appBaseUrl = "http://localhost:3000")],
    ["DISCLOSURE_MISSING", (i: LiveCallGateInput) => (i.settings.disclosureMessage = " ")],
    ["CONTACT_NOT_FOUND", (i: LiveCallGateInput) => (i.contact = null)],
    ["CONSENT_MISSING", (i: LiveCallGateInput) => (i.contact!.consentStatus = "pending")],
    ["CONSENT_MISSING", (i: LiveCallGateInput) => (i.contact!.consentStatus = "revoked")],
    ["CONSENT_SOURCE_MISSING", (i: LiveCallGateInput) => (i.contact!.consentSource = "")],
    ["DO_NOT_CALL", (i: LiveCallGateInput) => (i.contact!.status = "do_not_call")],
    ["CONTACT_INACTIVE", (i: LiveCallGateInput) => (i.contact!.status = "archived")],
    ["INVALID_NUMBER", (i: LiveCallGateInput) => (i.contact!.phone = "9876543210")],
    ["COUNTRY_NOT_ALLOWED", (i: LiveCallGateInput) => (i.contact!.country = "GB")],
    ["COUNTRY_NOT_ALLOWED", (i: LiveCallGateInput) => (i.server.allowedCountries = [])],
    ["CONFIRMATION_MISMATCH", (i: LiveCallGateInput) => (i.confirmation.confirmLast4 = "0000")],
    ["CHARGES_NOT_ACKNOWLEDGED", (i: LiveCallGateInput) => (i.confirmation.acknowledgedCharges = false)],
    ["RATE_LIMITED", (i: LiveCallGateInput) => (i.user.liveCallsInLastHour = 10)],
  ])("blocks with %s", (code, mutate) => {
    const i = passing();
    mutate(i);
    const r = evaluateLiveCallGate(i);
    expect(r.allowed).toBe(false);
    expect(r.reasons.map((x) => x.code)).toContain(code);
  });

  it("reports all failing reasons at once", () => {
    const i = passing();
    i.settings.testMode = true;
    i.server.liveCallsEnabled = false;
    i.contact!.consentStatus = "denied";
    expect(codes(i)).toEqual(expect.arrayContaining(["TEST_MODE", "SERVER_KILL_SWITCH", "CONSENT_MISSING"]));
  });
});
