import { defineConfig, devices } from "@playwright/test";

const PORT = 3100;

export default defineConfig({
  testDir: "tests/e2e",
  timeout: 60_000,
  fullyParallel: false,
  workers: 1,
  reporter: [["list"]],
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: "retain-on-failure",
  },
  projects: [
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
        launchOptions: { args: ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"] },
      },
    },
  ],
  webServer: {
    command: `npx next build && npx next start -p ${PORT}`,
    url: `http://localhost:${PORT}/api/status`,
    timeout: 240_000,
    reuseExistingServer: !process.env.CI,
    // Force free demo mode for e2e: no Supabase, no AI keys, no telecom.
    env: {
      NEXT_PUBLIC_SUPABASE_URL: "",
      NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: "",
      AI_PROVIDER: "demo",
      OPENAI_API_KEY: "",
      LIVE_CALLS_ENABLED: "false",
      TWILIO_ACCOUNT_SID: "",
      DEMO_PERSIST: "false",
    },
  },
});
