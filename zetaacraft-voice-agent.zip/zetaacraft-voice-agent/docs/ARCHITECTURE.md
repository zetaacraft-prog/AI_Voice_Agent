# Architecture

## Request flows

```
Browser voice (OpenAI configured)
  Browser ──POST /api/sessions──────────────▶ Next.js ── creates session row
  Browser ──POST /api/voice/realtime-token──▶ Next.js ──POST /v1/realtime/client_secrets──▶ OpenAI
          ◀────────── 120 s client secret ──
  Browser ══ WebRTC audio + "oai-events" data channel ═══════════════════════════════════▶ OpenAI
  Browser ──POST /api/sessions/:id/transcript (final turns) / :id/end──▶ Next.js

Browser voice (demo)
  Browser SpeechRecognition ─▶ POST /api/voice/demo-reply (rule-based) ─▶ speechSynthesis

Simulated call
  POST /api/calls/simulate ─▶ simulatedTelecom.placeCall (no network) ─▶ scripted transcript

Telephone call (Twilio)
  POST /api/calls/live ─▶ evaluateLiveCallGate ─▶ verifyCallerId ─▶ calls.create(url, statusCallback, timeLimit)
  Twilio ─▶ /api/telephony/twilio/voice   (signature + token) ─▶ <Say disclosure/><Gather speech>
  Twilio ─▶ /api/telephony/twilio/gather  (each utterance)     ─▶ AI reply ─▶ <Gather> … or opt-out ─▶ <Hangup>
  Twilio ─▶ /api/telephony/twilio/status  (initiated…completed) ─▶ status, duration
```

## Provider interfaces

- **`AIProvider`** (`src/lib/ai/provider.ts`): `createBrowserSession()` and `generateReply()`. Implementations: `demo` (mock, `isDemo: true`) and `openai`.
- **`TelecomProvider`** (`src/lib/telecom/types.ts`): `verifyCallerId()` and `placeCall()`, plus a `realNetwork` flag. Implementations: `simulated` (never dials) and `twilio`.
- **`Repository`** (`src/lib/data/repository.ts`): data access scoped to one user. Implementations: memory and Supabase. Telephone webhooks use `src/lib/data/webhook-store.ts` (service role, keyed by session id + hashed token).

To add a provider (for example Plivo, Vonage, Gemini Live, or ElevenLabs), implement the interface and register it in the factory (`getAIProvider` or `getLiveTelecomProvider`).

## Adding Telugu and Hindi
`src/lib/languages.ts` already has `te` and `hi` entries, with `te-IN`/`hi-IN` speech tags and greetings, marked `enabled: false`. To turn one on:
1. Check that your speech model and the Twilio `<Gather>`/`<Say>` voices support the language.
2. Set `enabled: true`, adjust the mock agent copy and `buildAgentInstructions`, and translate `DEFAULT_SETTINGS.disclosureMessage`.
3. Add tests. The settings API rejects disabled languages, so nothing else needs gating.

## Phase 2: streaming telephone audio
The MVP phone flow uses Twilio `<Gather input="speech">` turn by turn. It runs fine on serverless, but it has noticeable latency and no barge-in. For natural phone conversations:
1. Deploy a small persistent Node service (Fly.io, Render, Railway, or a container) with a WebSocket endpoint.
2. Have `/voice` return `<Connect><Stream url="wss://your-service/media?session=…&token=…"/></Connect>`.
3. In the service, bridge Twilio Media Streams (8 kHz μ-law) to a realtime speech model, which can accept `audio/pcmu`, and write transcript entries using the webhook store.
4. Keep the same safety gate. Calls are still placed only by `/api/calls/live`.

## Data model
`contacts`, `call_sessions`, `transcript_entries`, and `app_settings`. Each has an `owner_id` with RLS. `webhook_token_hash` is hidden from client roles through column grants. See `supabase/migrations/0001_init.sql`.
