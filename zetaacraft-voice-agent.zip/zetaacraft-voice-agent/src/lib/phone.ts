import { parsePhoneNumberFromString } from "libphonenumber-js";

export interface ParsedPhone {
  e164: string;
  country: string | null;
}

/** Parses a number that must include a country code (+...). Returns null if invalid. */
export function parsePhone(input: string): ParsedPhone | null {
  const trimmed = input.trim().replace(/[\s()-]/g, "");
  if (!trimmed.startsWith("+")) return null;
  const parsed = parsePhoneNumberFromString(trimmed);
  if (!parsed || !parsed.isValid()) return null;
  return { e164: parsed.number, country: parsed.country ?? null };
}

/** +919876543210 -> +91 ••••••3210 (for lists; full number only on the contact page). */
export function maskPhone(e164: string): string {
  const parsed = parsePhoneNumberFromString(e164);
  const last4 = e164.slice(-4);
  if (!parsed) return `••••${last4}`;
  return `+${parsed.countryCallingCode} ••••••${last4}`;
}
