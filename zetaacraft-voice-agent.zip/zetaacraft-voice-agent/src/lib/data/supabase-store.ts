import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import { DEFAULT_SETTINGS } from "../defaults";
import type { AppSettings, CallSession, Contact, TranscriptEntry } from "../types";
import type { Repository } from "./repository";

type Row = Record<string, unknown>;

export const SESSION_COLUMNS =
  "id, contact_id, contact_name, type, status, outcome, provider, provider_call_id, language, is_demo, started_at, ended_at, duration_sec, error_message";

export const toContact = (r: Row): Contact => ({
  id: r.id as string,
  name: r.name as string,
  phone: r.phone as string,
  country: r.country as string,
  purpose: r.purpose as string,
  consentStatus: r.consent_status as Contact["consentStatus"],
  consentSource: r.consent_source as string,
  consentAt: (r.consent_at as string) ?? null,
  notes: r.notes as string,
  status: r.status as Contact["status"],
  createdAt: r.created_at as string,
  updatedAt: r.updated_at as string,
});

const contactToRow = (c: Partial<Contact>): Row => {
  const map: Record<string, string> = {
    name: "name",
    phone: "phone",
    country: "country",
    purpose: "purpose",
    consentStatus: "consent_status",
    consentSource: "consent_source",
    consentAt: "consent_at",
    notes: "notes",
    status: "status",
  };
  const row: Row = {};
  for (const [k, v] of Object.entries(c)) if (k in map && v !== undefined) row[map[k]] = v;
  return row;
};

export const toSession = (r: Row): CallSession => ({
  id: r.id as string,
  contactId: (r.contact_id as string) ?? null,
  contactName: (r.contact_name as string) ?? null,
  type: r.type as CallSession["type"],
  status: r.status as CallSession["status"],
  outcome: r.outcome as string,
  provider: r.provider as string,
  providerCallId: (r.provider_call_id as string) ?? null,
  language: r.language as CallSession["language"],
  isDemo: r.is_demo as boolean,
  startedAt: r.started_at as string,
  endedAt: (r.ended_at as string) ?? null,
  durationSec: r.duration_sec as number,
  errorMessage: (r.error_message as string) ?? null,
});

export const sessionToRow = (s: Partial<CallSession> & { webhookTokenHash?: string | null }): Row => {
  const map: Record<string, string> = {
    contactId: "contact_id",
    contactName: "contact_name",
    type: "type",
    status: "status",
    outcome: "outcome",
    provider: "provider",
    providerCallId: "provider_call_id",
    language: "language",
    isDemo: "is_demo",
    startedAt: "started_at",
    endedAt: "ended_at",
    durationSec: "duration_sec",
    errorMessage: "error_message",
    webhookTokenHash: "webhook_token_hash",
  };
  const row: Row = {};
  for (const [k, v] of Object.entries(s)) if (k in map && v !== undefined) row[map[k]] = v;
  return row;
};

export const toSettings = (r: Row | null): AppSettings =>
  r
    ? {
        defaultLanguage: r.default_language as AppSettings["defaultLanguage"],
        testMode: r.test_mode as boolean,
        maxCallDurationSec: r.max_call_duration_sec as number,
        agentName: r.agent_name as string,
        disclosureMessage: r.disclosure_message as string,
        storeTranscripts: r.store_transcripts as boolean,
        transcriptRetentionDays: r.transcript_retention_days as number,
      }
    : { ...DEFAULT_SETTINGS };

const settingsToRow = (s: Partial<AppSettings>): Row => {
  const map: Record<string, string> = {
    defaultLanguage: "default_language",
    testMode: "test_mode",
    maxCallDurationSec: "max_call_duration_sec",
    agentName: "agent_name",
    disclosureMessage: "disclosure_message",
    storeTranscripts: "store_transcripts",
    transcriptRetentionDays: "transcript_retention_days",
  };
  const row: Row = {};
  for (const [k, v] of Object.entries(s)) if (k in map && v !== undefined) row[map[k]] = v;
  return row;
};

function check<T>(res: { data: T; error: { message: string } | null }): T {
  if (res.error) throw new Error(`Database error: ${res.error.message}`);
  return res.data;
}

export function createSupabaseRepository(db: SupabaseClient, userId: string): Repository {
  return {
    kind: "supabase",
    async listContacts() {
      return (check(await db.from("contacts").select("*").order("name")) as Row[]).map(toContact);
    },
    async getContact(id) {
      const r = check(await db.from("contacts").select("*").eq("id", id).maybeSingle()) as Row | null;
      return r ? toContact(r) : null;
    },
    async createContact(input) {
      const row = {
        ...contactToRow(input),
        owner_id: userId,
        consent_at: input.consentStatus === "granted" ? new Date().toISOString() : null,
      };
      return toContact(check(await db.from("contacts").insert(row).select("*").single()) as Row);
    },
    async updateContact(id, patch) {
      const current = await this.getContact(id);
      if (!current) return null;
      const row: Row = { ...contactToRow(patch), updated_at: new Date().toISOString() };
      if (patch.consentStatus && patch.consentStatus !== current.consentStatus) row.consent_at = new Date().toISOString();
      const r = check(await db.from("contacts").update(row).eq("id", id).select("*").maybeSingle()) as Row | null;
      return r ? toContact(r) : null;
    },
    async deleteContact(id) {
      const r = check(await db.from("contacts").delete().eq("id", id).select("id")) as Row[];
      return r.length > 0;
    },
    async listSessions(limit = 200) {
      return (
        check(await db.from("call_sessions").select(SESSION_COLUMNS).order("started_at", { ascending: false }).limit(limit)) as unknown as Row[]
      ).map(toSession);
    },
    async getSession(id) {
      const r = check(await db.from("call_sessions").select(SESSION_COLUMNS).eq("id", id).maybeSingle()) as unknown as Row | null;
      return r ? toSession(r) : null;
    },
    async createSession(s) {
      const row = { ...sessionToRow(s), owner_id: userId };
      return toSession(check(await db.from("call_sessions").insert(row).select(SESSION_COLUMNS).single()) as unknown as Row);
    },
    async updateSession(id, patch) {
      const r = check(
        await db.from("call_sessions").update(sessionToRow(patch)).eq("id", id).select(SESSION_COLUMNS).maybeSingle(),
      ) as unknown as Row | null;
      return r ? toSession(r) : null;
    },
    async countLiveCallsSince(sinceIso) {
      const res = await db
        .from("call_sessions")
        .select("id", { count: "exact", head: true })
        .eq("type", "telephone")
        .gte("started_at", sinceIso);
      if (res.error) throw new Error(`Database error: ${res.error.message}`);
      return res.count ?? 0;
    },
    async listTranscript(sessionId) {
      const rows = check(await db.from("transcript_entries").select("*").eq("session_id", sessionId).order("at")) as Row[];
      return rows.map(
        (r): TranscriptEntry => ({
          id: r.id as string,
          sessionId: r.session_id as string,
          role: r.role as TranscriptEntry["role"],
          text: r.text as string,
          at: r.at as string,
        }),
      );
    },
    async appendTranscript(sessionId, entries) {
      if (!entries.length) return;
      check(
        await db.from("transcript_entries").insert(
          entries.map((e) => ({
            session_id: sessionId,
            owner_id: userId,
            role: e.role,
            text: e.text,
            ...(e.at ? { at: e.at } : {}),
          })),
        ),
      );
    },
    async purgeTranscriptsBefore(beforeIso) {
      check(await db.from("transcript_entries").delete().lt("at", beforeIso));
    },
    async getSettings() {
      return toSettings(check(await db.from("app_settings").select("*").maybeSingle()) as Row | null);
    },
    async updateSettings(patch) {
      const current = await this.getSettings();
      const merged = { ...current, ...patch };
      const row = { ...settingsToRow(merged), owner_id: userId, updated_at: new Date().toISOString() };
      return toSettings(check(await db.from("app_settings").upsert(row).select("*").single()) as Row);
    },
  };
}
