import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { DEFAULT_SETTINGS } from "../defaults";
import type { AppSettings, CallSession, Contact, TranscriptEntry } from "../types";
import type { NewSession, Repository } from "./repository";
import { seedContacts } from "./seed";

interface DemoState {
  contacts: Contact[];
  sessions: (CallSession & { webhookTokenHash?: string | null })[];
  transcripts: TranscriptEntry[];
  settings: AppSettings;
}

const FILE = path.join(process.cwd(), ".data", "demo-store.json");
const g = globalThis as unknown as { __zetaDemoState?: DemoState };

function freshState(): DemoState {
  return { contacts: seedContacts(), sessions: [], transcripts: [], settings: { ...DEFAULT_SETTINGS } };
}

function load(persist: boolean): DemoState {
  if (g.__zetaDemoState) return g.__zetaDemoState;
  let state = freshState();
  if (persist) {
    try {
      const raw = JSON.parse(fs.readFileSync(FILE, "utf8")) as DemoState;
      state = { ...state, ...raw, settings: { ...DEFAULT_SETTINGS, ...raw.settings } };
    } catch {
      /* no file yet */
    }
  }
  // Demo data mode can never place real calls, but keep test mode on regardless.
  state.settings.testMode = true;
  g.__zetaDemoState = state;
  return state;
}

/** Test helper. */
export function resetDemoState() {
  g.__zetaDemoState = freshState();
}

export function createMemoryRepository(persist: boolean): Repository {
  const s = load(persist);
  const save = () => {
    if (!persist) return;
    try {
      fs.mkdirSync(path.dirname(FILE), { recursive: true });
      fs.writeFileSync(FILE, JSON.stringify(s, null, 2));
    } catch {
      /* read-only FS (e.g. serverless): keep in memory only */
    }
  };
  const nowIso = () => new Date().toISOString();
  const stripHash = (x: DemoState["sessions"][number]): CallSession => {
    const copy = { ...x };
    delete copy.webhookTokenHash;
    return copy;
  };

  return {
    kind: "memory",
    async listContacts() {
      return [...s.contacts].sort((a, b) => a.name.localeCompare(b.name));
    },
    async getContact(id) {
      return s.contacts.find((c) => c.id === id) ?? null;
    },
    async createContact(input) {
      const c: Contact = {
        ...input,
        id: randomUUID(),
        consentAt: input.consentStatus === "granted" ? nowIso() : null,
        createdAt: nowIso(),
        updatedAt: nowIso(),
      };
      s.contacts.push(c);
      save();
      return c;
    },
    async updateContact(id, patch) {
      const c = s.contacts.find((x) => x.id === id);
      if (!c) return null;
      const consentChanged = patch.consentStatus && patch.consentStatus !== c.consentStatus;
      Object.assign(c, patch, { updatedAt: nowIso() });
      if (consentChanged) c.consentAt = nowIso();
      save();
      return c;
    },
    async deleteContact(id) {
      const before = s.contacts.length;
      s.contacts = s.contacts.filter((c) => c.id !== id);
      s.sessions.forEach((x) => {
        if (x.contactId === id) x.contactId = null;
      });
      save();
      return s.contacts.length < before;
    },
    async listSessions(limit = 200) {
      return [...s.sessions]
        .sort((a, b) => b.startedAt.localeCompare(a.startedAt))
        .slice(0, limit)
        .map(stripHash);
    },
    async getSession(id) {
      const x = s.sessions.find((y) => y.id === id);
      return x ? stripHash(x) : null;
    },
    async createSession(input: NewSession) {
      const x = { ...input, id: randomUUID() };
      s.sessions.push(x);
      save();
      return stripHash(x);
    },
    async updateSession(id, patch) {
      const x = s.sessions.find((y) => y.id === id);
      if (!x) return null;
      Object.assign(x, patch, { id });
      save();
      return stripHash(x);
    },
    async countLiveCallsSince(sinceIso) {
      return s.sessions.filter((x) => x.type === "telephone" && x.startedAt >= sinceIso).length;
    },
    async listTranscript(sessionId) {
      return s.transcripts.filter((t) => t.sessionId === sessionId).sort((a, b) => a.at.localeCompare(b.at));
    },
    async appendTranscript(sessionId, entries) {
      for (const e of entries) {
        s.transcripts.push({ id: randomUUID(), sessionId, role: e.role, text: e.text, at: e.at ?? nowIso() });
      }
      save();
    },
    async purgeTranscriptsBefore(beforeIso) {
      const n = s.transcripts.length;
      s.transcripts = s.transcripts.filter((t) => t.at >= beforeIso);
      if (s.transcripts.length !== n) save();
    },
    async getSettings() {
      return { ...s.settings };
    },
    async updateSettings(patch) {
      Object.assign(s.settings, patch, { testMode: true });
      save();
      return { ...s.settings };
    },
  };
}
