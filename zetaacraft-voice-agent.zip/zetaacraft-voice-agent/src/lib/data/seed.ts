import type { Contact } from "../types";

const now = new Date().toISOString();

/** Sample contacts for demo mode. Numbers use reserved/fictional ranges. */
export function seedContacts(): Contact[] {
  const base = { createdAt: now, updatedAt: now, notes: "" };
  return [
    {
      ...base,
      id: "6f1c1d3e-1b2a-4c5d-8e9f-000000000001",
      name: "Ananya Rao (sample)",
      phone: "+919000000001",
      country: "IN",
      purpose: "Follow-up on website redesign enquiry",
      consentStatus: "granted",
      consentSource: "Website contact form (sample)",
      consentAt: now,
      status: "active",
      notes: "Prefers mornings.",
    },
    {
      ...base,
      id: "6f1c1d3e-1b2a-4c5d-8e9f-000000000002",
      name: "Daniel Carter (sample)",
      phone: "+12025550143",
      country: "US",
      purpose: "Demo booking for AI chatbot",
      consentStatus: "pending",
      consentSource: "",
      consentAt: null,
      status: "active",
    },
    {
      ...base,
      id: "6f1c1d3e-1b2a-4c5d-8e9f-000000000003",
      name: "Priya Sharma (sample)",
      phone: "+919000000003",
      country: "IN",
      purpose: "Customer feedback survey",
      consentStatus: "revoked",
      consentSource: "Event sign-up sheet (sample)",
      consentAt: now,
      status: "do_not_call",
      notes: "Asked not to be contacted.",
    },
  ];
}
