import "server-only";
import { createHash, timingSafeEqual } from "node:crypto";
import type { SupabaseClient } from "@supabase/supabase-js";
import { createSupabaseAdminClient } from "../supabase/server";
import type { AppSettings, CallSession, Contact, TranscriptEntry, TranscriptRole } from "../types";
import { SESSION_COLUMNS, sessionToRow, toContact, toSession, toSettings } from "./supabase-store";

/**
 * Service-role data access for telephone webhooks, which carry no user session.
 * Every lookup is keyed by session id AND a per-call secret token (stored hashed).
 */
export interface WebhookContext {
  db: SupabaseClient;
  ownerId: string;
  session: CallSession;
  settings: AppSettings;
  contact: Contact | null;
}

function tokenMatches(token: string, hash: string | null): boolean {
  if (!hash || !token) return false;
  const a = Buffer.from(createHash("sha256").update(token).digest("hex"));
  const b = Buffer.from(hash);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function loadWebhookContext(sessionId: string, token: string): Promise<WebhookContext | null> {
  const db = createSupabaseAdminClient();
  if (!db) return null;
  const { data: row } = await db
    .from("call_sessions")
    .select(`${SESSION_COLUMNS}, owner_id, webhook_token_hash`)
    .eq("id", sessionId)
    .eq("type", "telephone")
    .maybeSingle();
  if (!row || !tokenMatches(token, row.webhook_token_hash as string | null)) return null;
  const ownerId = row.owner_id as string;
  const [{ data: settingsRow }, contactRes] = await Promise.all([
    db.from("app_settings").select("*").eq("owner_id", ownerId).maybeSingle(),
    row.contact_id
      ? db.from("contacts").select("*").eq("id", row.contact_id).eq("owner_id", ownerId).maybeSingle()
      : Promise.resolve({ data: null }),
  ]);
  return {
    db,
    ownerId,
    session: toSession(row),
    settings: toSettings(settingsRow),
    contact: contactRes.data ? toContact(contactRes.data) : null,
  };
}

export async function webhookUpdateSession(ctx: WebhookContext, patch: Partial<CallSession>) {
  await ctx.db.from("call_sessions").update(sessionToRow(patch)).eq("id", ctx.session.id).eq("owner_id", ctx.ownerId);
}

export async function webhookAppendTranscript(ctx: WebhookContext, entries: { role: TranscriptRole; text: string }[]) {
  if (!entries.length) return;
  await ctx.db
    .from("transcript_entries")
    .insert(entries.map((e) => ({ ...e, session_id: ctx.session.id, owner_id: ctx.ownerId })));
}

export async function webhookListTranscript(ctx: WebhookContext): Promise<TranscriptEntry[]> {
  const { data } = await ctx.db
    .from("transcript_entries")
    .select("*")
    .eq("session_id", ctx.session.id)
    .order("at");
  return (data ?? []).map((r) => ({ id: r.id, sessionId: r.session_id, role: r.role, text: r.text, at: r.at }));
}

export async function webhookDeleteTranscript(ctx: WebhookContext) {
  await ctx.db.from("transcript_entries").delete().eq("session_id", ctx.session.id);
}

export async function webhookMarkDoNotCall(ctx: WebhookContext) {
  if (!ctx.contact) return;
  await ctx.db
    .from("contacts")
    .update({ status: "do_not_call", consent_status: "revoked", consent_at: new Date().toISOString(), updated_at: new Date().toISOString() })
    .eq("id", ctx.contact.id)
    .eq("owner_id", ctx.ownerId);
}
