import "server-only";
import { isSupabaseConfigured, serverEnv } from "../env";
import { createSupabaseServerClient } from "../supabase/server";
import { createMemoryRepository } from "./memory-store";
import type { Repository } from "./repository";
import { createSupabaseRepository } from "./supabase-store";

export interface RequestContext {
  mode: "supabase" | "demo";
  repo: Repository;
  user: { id: string; email: string | null } | null;
}

export class UnauthorizedError extends Error {
  constructor() {
    super("Not signed in");
  }
}

/**
 * Resolve the data repository for this request.
 * - Supabase mode: requires a signed-in user; RLS scopes all data to them.
 * - Demo mode: shared in-memory store (optionally persisted to .data/ in dev).
 */
export async function getRequestContext(): Promise<RequestContext> {
  const env = serverEnv();
  if (!isSupabaseConfigured(env)) {
    return { mode: "demo", repo: createMemoryRepository(env.demoPersist), user: null };
  }
  const db = await createSupabaseServerClient();
  const { data, error } = await db.auth.getUser();
  if (error || !data.user) throw new UnauthorizedError();
  return {
    mode: "supabase",
    repo: createSupabaseRepository(db, data.user.id),
    user: { id: data.user.id, email: data.user.email ?? null },
  };
}

export type { Repository };
