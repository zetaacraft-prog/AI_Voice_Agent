import type { ContactInput } from "../schemas";
import type { AppSettings, CallSession, Contact, TranscriptEntry, TranscriptRole } from "../types";

export type NewSession = Omit<CallSession, "id"> & { webhookTokenHash?: string | null };

/** Data access scoped to ONE user. Implementations: memory (demo) and Supabase (RLS). */
export interface Repository {
  kind: "memory" | "supabase";
  listContacts(): Promise<Contact[]>;
  getContact(id: string): Promise<Contact | null>;
  createContact(input: ContactInput): Promise<Contact>;
  updateContact(id: string, patch: Partial<ContactInput>): Promise<Contact | null>;
  deleteContact(id: string): Promise<boolean>;

  listSessions(limit?: number): Promise<CallSession[]>;
  getSession(id: string): Promise<CallSession | null>;
  createSession(s: NewSession): Promise<CallSession>;
  updateSession(id: string, patch: Partial<CallSession>): Promise<CallSession | null>;
  countLiveCallsSince(sinceIso: string): Promise<number>;

  listTranscript(sessionId: string): Promise<TranscriptEntry[]>;
  appendTranscript(sessionId: string, entries: { role: TranscriptRole; text: string; at?: string }[]): Promise<void>;
  purgeTranscriptsBefore(beforeIso: string): Promise<void>;

  getSettings(): Promise<AppSettings>;
  updateSettings(patch: Partial<AppSettings>): Promise<AppSettings>;
}
