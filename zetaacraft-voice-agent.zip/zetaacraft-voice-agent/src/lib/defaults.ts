import type { AppSettings } from "./types";

export const DEFAULT_SETTINGS: AppSettings = {
  defaultLanguage: "en",
  testMode: true,
  maxCallDurationSec: 300,
  agentName: "Zara",
  disclosureMessage:
    "Hi, this is Zara, an AI voice assistant calling on behalf of Zetaacraft. This call may be transcribed. You can say 'stop' at any time to end the call and opt out.",
  storeTranscripts: true,
  transcriptRetentionDays: 30,
};
