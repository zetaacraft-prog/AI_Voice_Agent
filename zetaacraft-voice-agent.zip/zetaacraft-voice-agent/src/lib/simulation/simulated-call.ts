import type { AppSettings, Contact, SessionStatus, TranscriptRole } from "../types";

export type SimScenario = "interested" | "callback" | "not_interested" | "no_answer" | "opt_out";

export interface SimulatedCallResult {
  scenario: SimScenario;
  status: SessionStatus;
  outcome: string;
  durationSec: number;
  /** Seconds offset from call start for each line. */
  lines: { role: TranscriptRole; text: string; offsetSec: number }[];
  markDoNotCall: boolean;
}

const SCENARIOS: SimScenario[] = ["interested", "callback", "not_interested", "no_answer", "opt_out"];

/** Pick a scenario deterministically from a seed so tests are stable. */
export function pickScenario(seed: string): SimScenario {
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return SCENARIOS[h % SCENARIOS.length];
}

/**
 * Builds a fully SIMULATED call. Nothing is dialed; both sides are scripted.
 * The first transcript line always states that the call is simulated.
 */
export function buildSimulatedCall(
  contact: Pick<Contact, "name" | "purpose">,
  settings: Pick<AppSettings, "agentName" | "disclosureMessage" | "maxCallDurationSec">,
  scenario: SimScenario,
): SimulatedCallResult {
  const first = contact.name.split(" ")[0] || contact.name;
  const purpose = contact.purpose || "a quick follow-up from Zetaacraft";
  const sys = { role: "system" as const, text: "SIMULATED CALL — no real phone was dialed. Both sides are scripted.", offsetSec: 0 };

  if (scenario === "no_answer") {
    return {
      scenario,
      status: "no_answer",
      outcome: "No answer (simulated)",
      durationSec: 0,
      lines: [sys, { role: "system", text: "Simulated: rang for 30 seconds with no answer.", offsetSec: 30 }],
      markDoNotCall: false,
    };
  }

  const script: [TranscriptRole, string][] = [
    ["agent", settings.disclosureMessage],
    ["user", "Hello? Yes, who is this?"],
    ["agent", `Hi ${first}, I'm ${settings.agentName} from Zetaacraft. I'm calling about ${purpose}. Is now a good time?`],
  ];
  const status: SessionStatus = "completed";
  let outcome = "";
  let markDoNotCall = false;

  switch (scenario) {
    case "interested":
      script.push(
        ["user", "Sure, I have a couple of minutes. Tell me more."],
        ["agent", "Wonderful. We help teams build AI-powered products. Would you like a short demo with our team this week?"],
        ["user", "Yes, Thursday afternoon works."],
        ["agent", "Perfect, I'll note Thursday afternoon and a team member will confirm by email. Thanks, goodbye!"],
      );
      outcome = "Interested — demo requested (simulated)";
      break;
    case "callback":
      script.push(
        ["user", "I'm a bit busy right now. Can you call me back later?"],
        ["agent", "Of course. What time works best for a callback?"],
        ["user", "Tomorrow around 11 AM."],
        ["agent", "Noted — tomorrow around 11 AM. Thank you, goodbye!"],
      );
      outcome = "Callback requested (simulated)";
      break;
    case "not_interested":
      script.push(
        ["user", "Thanks, but we're not looking for this right now."],
        ["agent", "I understand, thank you for letting me know. Have a great day!"],
      );
      outcome = "Not interested (simulated)";
      break;
    case "opt_out":
      script.push(
        ["user", "Please stop calling me and remove me from your list."],
        ["agent", "Understood. I've marked that you don't want to be contacted again. Goodbye."],
      );
      outcome = "Opted out — contact marked do-not-call (simulated)";
      markDoNotCall = true;
      break;
  }

  let t = 2;
  const lines: SimulatedCallResult["lines"] = [sys];
  for (const [role, text] of script) {
    lines.push({ role, text, offsetSec: t });
    t += Math.max(3, Math.round(text.split(" ").length / 2.5));
  }
  const durationSec = Math.min(t, settings.maxCallDurationSec);
  return { scenario, status, outcome, durationSec, lines, markDoNotCall };
}
