import "server-only";
import { NextResponse } from "next/server";
import { z } from "zod";
import { UnauthorizedError } from "./data";

export function jsonError(status: number, error: string, details?: unknown) {
  return NextResponse.json({ error, ...(details !== undefined ? { details } : {}) }, { status });
}

export async function parseBody<S extends z.ZodType>(req: Request, schema: S): Promise<z.output<S>> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    throw new BadRequestError("Body must be valid JSON");
  }
  const result = schema.safeParse(raw);
  if (!result.success) throw new BadRequestError("Validation failed", z.flattenError(result.error));
  return result.data;
}

export class BadRequestError extends Error {
  constructor(
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

/** Wraps a route handler with consistent error mapping. Never leaks stack traces or secrets. */
export function handle<A extends unknown[]>(fn: (...args: A) => Promise<Response>) {
  return async (...args: A): Promise<Response> => {
    try {
      return await fn(...args);
    } catch (err) {
      if (err instanceof UnauthorizedError) return jsonError(401, "Please sign in.");
      if (err instanceof BadRequestError) return jsonError(400, err.message, err.details);
      console.error("[api]", err instanceof Error ? err.message : err);
      return jsonError(500, "Something went wrong on the server. Check the server logs.");
    }
  };
}
