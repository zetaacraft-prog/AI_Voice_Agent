"use client";

import type { ChatTurn } from "../types";

export type EngineState = "idle" | "requesting_mic" | "connecting" | "live" | "ending" | "error";

export interface EngineCallbacks {
  onState(state: EngineState): void;
  /** final=false for streaming partials (shown greyed out), true when the turn is complete. */
  onTranscript(role: "agent" | "user", text: string, final: boolean): void;
  onAgentSpeaking(speaking: boolean): void;
  onUserSpeaking(speaking: boolean): void;
  onLevel(level: number): void;
  onError(message: string): void;
  onEnd?(reason: string): void;
}

export interface VoiceEngine {
  readonly label: string;
  readonly isDemo: boolean;
  start(): Promise<void>;
  stop(): void;
  setMuted(muted: boolean): void;
  sendText(text: string): void;
}

/** Friendly explanation for getUserMedia failures. */
export function micErrorMessage(err: unknown): string {
  const name = err instanceof DOMException ? err.name : "";
  if (name === "NotAllowedError" || name === "SecurityError")
    return "Microphone permission was denied. Click the lock/site-settings icon in the address bar, allow the microphone, then try again.";
  if (name === "NotFoundError") return "No microphone was found. Connect a microphone and try again.";
  if (name === "NotReadableError") return "Your microphone is in use by another application.";
  if (typeof window !== "undefined" && !window.isSecureContext)
    return "Microphone access requires HTTPS or http://localhost.";
  return err instanceof Error ? err.message : "Could not access the microphone.";
}

export async function getMicrophone(): Promise<MediaStream> {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error("This browser does not support microphone access.");
  return navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
}

/** Mic level meter (0..1) via Web Audio analyser. Returns a stop function. */
export function startLevelMeter(stream: MediaStream, onLevel: (l: number) => void): () => void {
  const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AC();
  const src = ctx.createMediaStreamSource(stream);
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 512;
  src.connect(analyser);
  const buf = new Uint8Array(analyser.fftSize);
  let raf = 0;
  const tick = () => {
    analyser.getByteTimeDomainData(buf);
    let sum = 0;
    for (const v of buf) sum += ((v - 128) / 128) ** 2;
    onLevel(Math.min(1, Math.sqrt(sum / buf.length) * 4));
    raf = requestAnimationFrame(tick);
  };
  tick();
  return () => {
    cancelAnimationFrame(raf);
    void ctx.close();
  };
}

// ─── OpenAI Realtime (WebRTC) ───────────────────────────────────────────────

export interface RealtimeToken {
  clientSecret: string;
  sdpUrl: string;
  model: string;
}

export class OpenAIRealtimeEngine implements VoiceEngine {
  readonly label = "OpenAI Realtime (WebRTC)";
  readonly isDemo = false;
  private pc: RTCPeerConnection | null = null;
  private dc: RTCDataChannel | null = null;
  private stream: MediaStream | null = null;
  private audioEl: HTMLAudioElement | null = null;
  private stopMeter: (() => void) | null = null;
  private agentPartial = "";
  private userPartial = "";

  constructor(
    private token: RealtimeToken,
    private cb: EngineCallbacks,
  ) {}

  async start() {
    this.cb.onState("requesting_mic");
    try {
      this.stream = await getMicrophone();
    } catch (e) {
      throw new Error(micErrorMessage(e));
    }
    this.stopMeter = startLevelMeter(this.stream, this.cb.onLevel);
    this.cb.onState("connecting");

    const pc = new RTCPeerConnection();
    this.pc = pc;
    this.audioEl = new Audio();
    this.audioEl.autoplay = true;
    pc.ontrack = (e) => {
      if (this.audioEl) this.audioEl.srcObject = e.streams[0];
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "failed") {
        this.cb.onError("Voice connection failed (network/firewall may be blocking WebRTC).");
        this.cb.onEnd?.("connection_failed");
      }
    };
    this.stream.getAudioTracks().forEach((t) => pc.addTrack(t, this.stream!));

    const dc = pc.createDataChannel("oai-events");
    this.dc = dc;
    dc.onmessage = (e) => this.handleEvent(JSON.parse(e.data));
    dc.onopen = () => {
      this.cb.onState("live");
      // Ask the agent to greet first.
      dc.send(JSON.stringify({ type: "response.create" }));
    };

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    const res = await fetch(this.token.sdpUrl, {
      method: "POST",
      body: offer.sdp,
      headers: { Authorization: `Bearer ${this.token.clientSecret}`, "Content-Type": "application/sdp" },
    });
    if (!res.ok) throw new Error(`AI provider rejected the voice connection (${res.status}).`);
    await pc.setRemoteDescription({ type: "answer", sdp: await res.text() });
  }

  private handleEvent(ev: { type: string; delta?: string; transcript?: string; error?: { message?: string } }) {
    switch (ev.type) {
      case "input_audio_buffer.speech_started":
        this.cb.onUserSpeaking(true);
        break;
      case "input_audio_buffer.speech_stopped":
        this.cb.onUserSpeaking(false);
        break;
      case "conversation.item.input_audio_transcription.delta":
        this.userPartial += ev.delta ?? "";
        this.cb.onTranscript("user", this.userPartial, false);
        break;
      case "conversation.item.input_audio_transcription.completed":
        this.userPartial = "";
        if (ev.transcript?.trim()) this.cb.onTranscript("user", ev.transcript.trim(), true);
        break;
      case "response.output_audio_transcript.delta":
        this.agentPartial += ev.delta ?? "";
        this.cb.onAgentSpeaking(true);
        this.cb.onTranscript("agent", this.agentPartial, false);
        break;
      case "response.output_audio_transcript.done":
        this.agentPartial = "";
        if (ev.transcript?.trim()) this.cb.onTranscript("agent", ev.transcript.trim(), true);
        break;
      case "response.done":
        this.cb.onAgentSpeaking(false);
        break;
      case "error":
        this.cb.onError(ev.error?.message ?? "AI provider error");
        break;
    }
  }

  setMuted(muted: boolean) {
    this.stream?.getAudioTracks().forEach((t) => (t.enabled = !muted));
  }

  sendText(text: string) {
    if (this.dc?.readyState !== "open") return;
    this.dc.send(
      JSON.stringify({
        type: "conversation.item.create",
        item: { type: "message", role: "user", content: [{ type: "input_text", text }] },
      }),
    );
    this.dc.send(JSON.stringify({ type: "response.create" }));
    this.cb.onTranscript("user", text, true);
  }

  stop() {
    this.stopMeter?.();
    this.dc?.close();
    this.pc?.getSenders().forEach((s) => s.track?.stop());
    this.pc?.close();
    this.stream?.getTracks().forEach((t) => t.stop());
    if (this.audioEl) this.audioEl.srcObject = null;
    this.pc = null;
    this.dc = null;
  }
}

// ─── Demo engine: browser speech APIs + mock replies (free) ─────────────────

interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((e: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  onspeechstart: (() => void) | null;
  onspeechend: (() => void) | null;
}

export function getSpeechRecognition(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as Record<string, unknown>;
  return (w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null) as (new () => SpeechRecognitionLike) | null;
}

export class DemoSpeechEngine implements VoiceEngine {
  readonly label = "Demo — browser speech + mock AI";
  readonly isDemo = true;
  private rec: SpeechRecognitionLike | null = null;
  private stream: MediaStream | null = null;
  private stopMeter: (() => void) | null = null;
  private muted = false;
  private speaking = false;
  private active = false;
  private history: ChatTurn[] = [];

  constructor(
    private opts: { lang: string; greeting: string },
    private cb: EngineCallbacks,
  ) {}

  /** True if the browser can do speech-to-text; otherwise the UI offers typed input. */
  static supportsRecognition() {
    return getSpeechRecognition() !== null;
  }

  async start() {
    this.cb.onState("requesting_mic");
    try {
      this.stream = await getMicrophone();
    } catch (e) {
      throw new Error(micErrorMessage(e));
    }
    this.stopMeter = startLevelMeter(this.stream, this.cb.onLevel);
    this.active = true;
    const SR = getSpeechRecognition();
    if (SR) {
      const rec = new SR();
      rec.lang = this.opts.lang;
      rec.continuous = true;
      rec.interimResults = true;
      rec.onspeechstart = () => this.cb.onUserSpeaking(true);
      rec.onspeechend = () => this.cb.onUserSpeaking(false);
      rec.onresult = (e) => {
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const r = e.results[i];
          const text = r[0].transcript.trim();
          if (!text) continue;
          if (r.isFinal) void this.handleUser(text);
          else this.cb.onTranscript("user", text, false);
        }
      };
      rec.onerror = (e) => {
        if (e.error === "not-allowed") this.cb.onError("Speech recognition permission denied.");
        else if (e.error === "network") this.cb.onError("Browser speech recognition needs an internet connection (Chrome sends audio to Google).");
        else if (e.error !== "no-speech" && e.error !== "aborted") this.cb.onError(`Speech recognition error: ${e.error}`);
      };
      // Chrome stops recognition periodically; restart while the session is active.
      rec.onend = () => {
        if (this.active && !this.muted && !this.speaking) this.safeStart();
      };
      this.rec = rec;
    }
    this.cb.onState("live");
    await this.say(this.opts.greeting);
  }

  private safeStart() {
    try {
      this.rec?.start();
    } catch {
      /* already started */
    }
  }

  private async handleUser(text: string) {
    this.cb.onTranscript("user", text, true);
    const history = [...this.history];
    this.history.push({ role: "user", text });
    try {
      const res = await fetch("/api/voice/demo-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, history: history.slice(-20) }),
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? "Demo reply failed");
      const data = (await res.json()) as { text: string; endConversation: boolean };
      await this.say(data.text);
      if (data.endConversation) this.cb.onEnd?.("agent_ended");
    } catch (e) {
      this.cb.onError(e instanceof Error ? e.message : "Demo reply failed");
    }
  }

  private say(text: string): Promise<void> {
    this.history.push({ role: "agent", text });
    this.cb.onTranscript("agent", text, true);
    if (!("speechSynthesis" in window)) return Promise.resolve();
    return new Promise((resolve) => {
      // Pause listening while speaking so the agent doesn't hear itself.
      this.speaking = true;
      this.rec?.abort();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = this.opts.lang;
      u.rate = 1.02;
      let finished = false;
      // Some browsers never fire onend (known Chrome bug / no voices installed): fall back to a timer.
      const fallback = window.setTimeout(() => done(), 2000 + text.split(" ").length * 450);
      const done = () => {
        if (finished) return;
        finished = true;
        window.clearTimeout(fallback);
        this.speaking = false;
        this.cb.onAgentSpeaking(false);
        if (this.active && !this.muted) this.safeStart();
        resolve();
      };
      u.onstart = () => this.cb.onAgentSpeaking(true);
      u.onend = done;
      u.onerror = done;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    });
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    this.stream?.getAudioTracks().forEach((t) => (t.enabled = !muted));
    if (muted) this.rec?.abort();
    else if (!this.speaking) this.safeStart();
  }

  sendText(text: string) {
    void this.handleUser(text);
  }

  stop() {
    this.active = false;
    this.rec?.abort();
    this.rec = null;
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    this.stopMeter?.();
    this.stream?.getTracks().forEach((t) => t.stop());
  }
}
