import type { AppSettings, Contact } from "../types";

/**
 * Every condition that must hold before a REAL telephone call is placed.
 * Pure function: no I/O, so it is exhaustively unit-tested. The telecom provider
 * additionally verifies the caller ID with the provider right before dialing.
 */
export interface LiveCallGateInput {
  server: {
    liveCallsEnabled: boolean;
    supabaseMode: boolean;
    telecomConfigured: boolean;
    webhookServiceRoleConfigured: boolean;
    appBaseUrl: string;
    allowedCountries: string[];
    maxLiveCallsPerHour: number;
  };
  user: { authenticated: boolean; liveCallsInLastHour: number };
  settings: Pick<AppSettings, "testMode" | "disclosureMessage">;
  contact: Pick<Contact, "phone" | "country" | "consentStatus" | "consentSource" | "status"> | null;
  confirmation: { confirmLast4: string; acknowledgedCharges: boolean };
}

export type GateCode =
  | "SERVER_KILL_SWITCH"
  | "DEMO_DATA_MODE"
  | "NOT_AUTHENTICATED"
  | "TEST_MODE"
  | "TELECOM_NOT_CONFIGURED"
  | "WEBHOOK_STORE_NOT_CONFIGURED"
  | "WEBHOOK_URL_NOT_HTTPS"
  | "CONTACT_NOT_FOUND"
  | "CONSENT_MISSING"
  | "CONSENT_SOURCE_MISSING"
  | "DO_NOT_CALL"
  | "CONTACT_INACTIVE"
  | "COUNTRY_NOT_ALLOWED"
  | "INVALID_NUMBER"
  | "DISCLOSURE_MISSING"
  | "CONFIRMATION_MISMATCH"
  | "CHARGES_NOT_ACKNOWLEDGED"
  | "RATE_LIMITED";

export interface GateReason {
  code: GateCode;
  message: string;
}

export interface GateResult {
  allowed: boolean;
  reasons: GateReason[];
}

export function evaluateLiveCallGate(input: LiveCallGateInput): GateResult {
  const reasons: GateReason[] = [];
  const add = (code: GateCode, message: string) => reasons.push({ code, message });
  const { server, user, settings, contact, confirmation } = input;

  if (!server.liveCallsEnabled)
    add("SERVER_KILL_SWITCH", "Live calling is disabled on the server (LIVE_CALLS_ENABLED is not 'true').");
  if (!server.supabaseMode)
    add("DEMO_DATA_MODE", "Live calls require Supabase mode with a signed-in user; demo data mode is simulation-only.");
  if (!user.authenticated) add("NOT_AUTHENTICATED", "You must be signed in to place a live call.");
  // Test mode is checked independently of every other flag: it alone blocks dialing.
  if (settings.testMode !== false) add("TEST_MODE", "Test mode is ON. Real telephone calls are never placed in test mode.");
  if (!server.telecomConfigured) add("TELECOM_NOT_CONFIGURED", "Telecom provider credentials or caller ID are not configured.");
  if (!server.webhookServiceRoleConfigured)
    add("WEBHOOK_STORE_NOT_CONFIGURED", "SUPABASE_SERVICE_ROLE_KEY is required so call webhooks can record status.");
  if (!/^https:\/\//.test(server.appBaseUrl))
    add("WEBHOOK_URL_NOT_HTTPS", "APP_BASE_URL must be a public https URL so the provider can reach the webhooks.");
  if (!settings.disclosureMessage || settings.disclosureMessage.trim().length < 10)
    add("DISCLOSURE_MISSING", "An AI disclosure message is required for live calls.");

  if (!contact) {
    add("CONTACT_NOT_FOUND", "Contact not found.");
  } else {
    if (contact.consentStatus !== "granted")
      add("CONSENT_MISSING", `Contact consent is '${contact.consentStatus}'. Only contacts with granted consent can be called.`);
    else if (!contact.consentSource.trim())
      add("CONSENT_SOURCE_MISSING", "Consent source is not recorded for this contact.");
    if (contact.status === "do_not_call") add("DO_NOT_CALL", "Contact is on the do-not-call list.");
    else if (contact.status !== "active") add("CONTACT_INACTIVE", "Contact is not active.");
    if (!/^\+[1-9]\d{6,14}$/.test(contact.phone)) add("INVALID_NUMBER", "Contact phone is not a valid E.164 number.");
    if (!server.allowedCountries.includes(contact.country.toUpperCase()))
      add(
        "COUNTRY_NOT_ALLOWED",
        `Destination country '${contact.country || "unknown"}' is not in LIVE_CALL_ALLOWED_COUNTRIES (${server.allowedCountries.join(", ") || "none"}).`,
      );
    if (confirmation.confirmLast4 !== contact.phone.slice(-4))
      add("CONFIRMATION_MISMATCH", "Typed digits do not match the last 4 digits of the contact's number.");
  }

  if (confirmation.acknowledgedCharges !== true)
    add("CHARGES_NOT_ACKNOWLEDGED", "You must acknowledge that live calls are billed by the telecom provider.");
  if (user.liveCallsInLastHour >= server.maxLiveCallsPerHour)
    add("RATE_LIMITED", `Hourly live call limit reached (${server.maxLiveCallsPerHour}).`);

  return { allowed: reasons.length === 0, reasons };
}
