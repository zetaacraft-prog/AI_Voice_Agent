import "server-only";
import type { RequestContext } from "../data";
import { isTwilioConfigured, serverEnv } from "../env";
import type { Contact } from "../types";
import { evaluateLiveCallGate, type GateResult } from "./live-call-gate";

export async function evaluateGateForRequest(
  ctx: RequestContext,
  contact: Contact | null,
  confirmation: { confirmLast4: string; acknowledgedCharges: boolean },
): Promise<GateResult> {
  const env = serverEnv();
  const settings = await ctx.repo.getSettings();
  const since = new Date(Date.now() - 3_600_000).toISOString();
  return evaluateLiveCallGate({
    server: {
      liveCallsEnabled: env.liveCallsEnabled,
      supabaseMode: ctx.mode === "supabase",
      telecomConfigured: isTwilioConfigured(env),
      webhookServiceRoleConfigured: Boolean(env.supabaseServiceRoleKey),
      appBaseUrl: env.appBaseUrl,
      allowedCountries: env.allowedCountries,
      maxLiveCallsPerHour: env.maxLiveCallsPerHour,
    },
    user: { authenticated: Boolean(ctx.user), liveCallsInLastHour: await ctx.repo.countLiveCallsSince(since) },
    settings,
    contact,
    confirmation,
  });
}
