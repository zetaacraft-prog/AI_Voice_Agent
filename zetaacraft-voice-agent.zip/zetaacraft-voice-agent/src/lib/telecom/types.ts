export interface CallerIdCheck {
  ok: boolean;
  kind: "provider_number" | "verified_caller_id" | null;
  message: string;
}

export interface PlaceCallRequest {
  to: string;
  sessionId: string;
  webhookToken: string;
  maxDurationSec: number;
  baseUrl: string;
}

/**
 * Telecom provider abstraction. Implementations: `simulated` (never dials) and
 * `twilio` (real, billed calls). Add e.g. Plivo/Vonage by implementing this.
 */
export interface TelecomProvider {
  id: "simulated" | "twilio";
  /** True only for providers that reach the real telephone network. */
  realNetwork: boolean;
  verifyCallerId(): Promise<CallerIdCheck>;
  placeCall(req: PlaceCallRequest): Promise<{ providerCallId: string }>;
}
