import type { TelecomProvider } from "./types";

/** Never touches the telephone network. Used for the simulated call workflow. */
export const simulatedTelecom: TelecomProvider = {
  id: "simulated",
  realNetwork: false,
  async verifyCallerId() {
    return { ok: true, kind: null, message: "Simulated provider: no caller ID is used." };
  },
  async placeCall(req) {
    return { providerCallId: `SIM-${req.sessionId.slice(0, 8)}` };
  },
};
