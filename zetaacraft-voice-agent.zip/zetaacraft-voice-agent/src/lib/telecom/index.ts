import "server-only";
import { isTwilioConfigured, serverEnv } from "../env";
import { simulatedTelecom } from "./simulated";
import { twilioTelecom } from "./twilio";
import type { TelecomProvider } from "./types";

/** The real-network provider, or null when not configured. Callers MUST pass the safety gate first. */
export function getLiveTelecomProvider(): TelecomProvider | null {
  const env = serverEnv();
  if (env.telecomProvider === "twilio" && isTwilioConfigured(env)) return twilioTelecom();
  return null;
}

export { simulatedTelecom };
