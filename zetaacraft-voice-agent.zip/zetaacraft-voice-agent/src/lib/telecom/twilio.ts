import "server-only";
import twilio from "twilio";
import { serverEnv } from "../env";
import type { CallerIdCheck, TelecomProvider } from "./types";

let callerIdCache: { value: string; result: CallerIdCheck; at: number } | null = null;
const CALLER_ID_TTL_MS = 10 * 60 * 1000;

export function twilioTelecom(): TelecomProvider {
  const env = serverEnv();
  const client = twilio(env.twilioAccountSid, env.twilioAuthToken);

  return {
    id: "twilio",
    realNetwork: true,

    /**
     * Twilio only permits a `from` that is a Twilio number on the account or a
     * Verified Outgoing Caller ID. We check both before every call (cached 10 min).
     */
    async verifyCallerId() {
      const callerId = env.twilioCallerId;
      if (callerIdCache && callerIdCache.value === callerId && Date.now() - callerIdCache.at < CALLER_ID_TTL_MS) {
        return callerIdCache.result;
      }
      let result: CallerIdCheck;
      const owned = await client.incomingPhoneNumbers.list({ phoneNumber: callerId, limit: 1 });
      if (owned.length > 0) {
        result = { ok: true, kind: "provider_number", message: "Caller ID is a Twilio number on this account." };
      } else {
        const verified = await client.outgoingCallerIds.list({ phoneNumber: callerId, limit: 1 });
        result =
          verified.length > 0
            ? { ok: true, kind: "verified_caller_id", message: "Caller ID is a verified outgoing caller ID." }
            : {
                ok: false,
                kind: null,
                message:
                  "TWILIO_CALLER_ID is neither a Twilio number on this account nor a verified caller ID. Verify it in the Twilio Console first.",
              };
      }
      callerIdCache = { value: callerId, result, at: Date.now() };
      return result;
    },

    async placeCall({ to, sessionId, webhookToken, maxDurationSec, baseUrl }) {
      const q = `session=${encodeURIComponent(sessionId)}&token=${encodeURIComponent(webhookToken)}`;
      const call = await client.calls.create({
        to,
        from: env.twilioCallerId,
        url: `${baseUrl}/api/telephony/twilio/voice?${q}`,
        method: "POST",
        statusCallback: `${baseUrl}/api/telephony/twilio/status?${q}`,
        statusCallbackMethod: "POST",
        statusCallbackEvent: ["initiated", "ringing", "answered", "completed"],
        timeLimit: maxDurationSec,
        timeout: 30,
      });
      return { providerCallId: call.sid };
    },
  };
}

/** Validates the X-Twilio-Signature header against the full public URL + POST params. */
export function validateTwilioSignature(signature: string | null, url: string, params: Record<string, string>): boolean {
  if (!signature) return false;
  return twilio.validateRequest(serverEnv().twilioAuthToken, signature, url, params);
}
