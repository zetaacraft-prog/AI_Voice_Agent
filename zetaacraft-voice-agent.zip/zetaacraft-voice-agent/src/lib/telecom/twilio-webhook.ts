import "server-only";
import twilio from "twilio";
import { serverEnv } from "../env";
import { loadWebhookContext, type WebhookContext } from "../data/webhook-store";
import { validateTwilioSignature } from "./twilio";

export type VoiceResponse = InstanceType<typeof twilio.twiml.VoiceResponse>;

export function twimlResponse(vr: VoiceResponse): Response {
  return new Response(vr.toString(), { headers: { "Content-Type": "text/xml" } });
}

export function hangupTwiml(message?: string): Response {
  const vr = new twilio.twiml.VoiceResponse();
  if (message) vr.say(message);
  vr.hangup();
  return twimlResponse(vr);
}

/**
 * Verifies a Twilio webhook: X-Twilio-Signature over the PUBLIC url (APP_BASE_URL),
 * then the per-call token, then that the CallSid matches the session.
 */
export async function verifyTwilioWebhook(
  req: Request,
): Promise<{ ok: true; ctx: WebhookContext; params: Record<string, string> } | { ok: false; status: number }> {
  const url = new URL(req.url);
  const publicUrl = `${serverEnv().appBaseUrl}${url.pathname}${url.search}`;
  const form = await req.formData();
  const params: Record<string, string> = {};
  form.forEach((v, k) => {
    if (typeof v === "string") params[k] = v;
  });
  if (!validateTwilioSignature(req.headers.get("x-twilio-signature"), publicUrl, params)) {
    return { ok: false, status: 403 };
  }
  const ctx = await loadWebhookContext(url.searchParams.get("session") ?? "", url.searchParams.get("token") ?? "");
  if (!ctx) return { ok: false, status: 404 };
  if (ctx.session.providerCallId && params.CallSid && ctx.session.providerCallId !== params.CallSid) {
    return { ok: false, status: 409 };
  }
  return { ok: true, ctx, params };
}

export function gatherUrl(ctx: WebhookContext, req: Request): string {
  const url = new URL(req.url);
  return `${serverEnv().appBaseUrl}/api/telephony/twilio/gather?session=${encodeURIComponent(ctx.session.id)}&token=${encodeURIComponent(url.searchParams.get("token") ?? "")}`;
}
