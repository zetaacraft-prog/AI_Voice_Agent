import "server-only";

/**
 * Server-side configuration. Read lazily so tests can stub process.env.
 * Nothing in here may be sent to the browser except via `publicConfigStatus()`,
 * which only exposes booleans and non-secret labels.
 */
export function serverEnv() {
  const e = process.env;
  const allowed = (e.LIVE_CALL_ALLOWED_COUNTRIES ?? "")
    .split(",")
    .map((c) => c.trim().toUpperCase())
    .filter((c) => /^[A-Z]{2}$/.test(c));
  return {
    appBaseUrl: (e.APP_BASE_URL ?? "http://localhost:3000").replace(/\/$/, ""),
    supabaseUrl: e.NEXT_PUBLIC_SUPABASE_URL ?? "",
    supabaseKey: e.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? e.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "",
    supabaseServiceRoleKey: e.SUPABASE_SERVICE_ROLE_KEY ?? "",
    aiProvider: (e.AI_PROVIDER ?? "demo") === "openai" ? ("openai" as const) : ("demo" as const),
    openaiApiKey: e.OPENAI_API_KEY ?? "",
    openaiRealtimeModel: e.OPENAI_REALTIME_MODEL || "gpt-realtime",
    openaiRealtimeVoice: e.OPENAI_REALTIME_VOICE || "marin",
    openaiTranscribeModel: e.OPENAI_TRANSCRIBE_MODEL || "gpt-4o-mini-transcribe",
    openaiTextModel: e.OPENAI_TEXT_MODEL || "gpt-5.4-mini",
    liveCallsEnabled: e.LIVE_CALLS_ENABLED === "true",
    telecomProvider: e.TELECOM_PROVIDER || "twilio",
    twilioAccountSid: e.TWILIO_ACCOUNT_SID ?? "",
    twilioAuthToken: e.TWILIO_AUTH_TOKEN ?? "",
    twilioCallerId: e.TWILIO_CALLER_ID ?? "",
    allowedCountries: allowed,
    maxLiveCallsPerHour: Math.max(1, Number(e.LIVE_CALLS_MAX_PER_HOUR) || 10),
    demoPersist: e.DEMO_PERSIST !== "false" && e.NODE_ENV !== "production",
    isProduction: e.NODE_ENV === "production",
  };
}
export type ServerEnv = ReturnType<typeof serverEnv>;

export function isSupabaseConfigured(env = serverEnv()): boolean {
  return Boolean(env.supabaseUrl && env.supabaseKey);
}

export function isOpenAIConfigured(env = serverEnv()): boolean {
  return env.aiProvider === "openai" && env.openaiApiKey.startsWith("sk-");
}

export function isTwilioConfigured(env = serverEnv()): boolean {
  return (
    env.telecomProvider === "twilio" &&
    /^AC[0-9a-f]{32}$/i.test(env.twilioAccountSid) &&
    env.twilioAuthToken.length >= 32 &&
    /^\+[1-9]\d{6,14}$/.test(env.twilioCallerId)
  );
}

export interface PublicConfigStatus {
  dataMode: "supabase" | "demo";
  ai: { provider: "demo" | "openai"; configured: boolean; realtimeModel: string | null };
  telecom: {
    provider: string;
    configured: boolean;
    liveCallsEnabledByServer: boolean;
    webhooksReachable: boolean;
    callerIdMasked: string | null;
    allowedCountries: string[];
    webhookServiceRoleConfigured: boolean;
  };
  warnings: string[];
}

export function publicConfigStatus(env = serverEnv()): PublicConfigStatus {
  const warnings: string[] = [];
  const supabase = isSupabaseConfigured(env);
  if (!supabase && env.isProduction) {
    warnings.push(
      "Running in DEMO data mode in production: data is in memory and there is no login. Configure Supabase before sharing this URL.",
    );
  }
  if (env.aiProvider === "openai" && !isOpenAIConfigured(env)) {
    warnings.push("AI_PROVIDER=openai but OPENAI_API_KEY is missing or malformed. Falling back to demo responses.");
  }
  return {
    dataMode: supabase ? "supabase" : "demo",
    ai: {
      provider: isOpenAIConfigured(env) ? "openai" : "demo",
      configured: isOpenAIConfigured(env),
      realtimeModel: isOpenAIConfigured(env) ? env.openaiRealtimeModel : null,
    },
    telecom: {
      provider: env.telecomProvider,
      configured: isTwilioConfigured(env),
      liveCallsEnabledByServer: env.liveCallsEnabled,
      webhooksReachable: env.appBaseUrl.startsWith("https://"),
      callerIdMasked: env.twilioCallerId ? `••••${env.twilioCallerId.slice(-4)}` : null,
      allowedCountries: env.allowedCountries,
      webhookServiceRoleConfigured: Boolean(env.supabaseServiceRoleKey),
    },
    warnings,
  };
}
