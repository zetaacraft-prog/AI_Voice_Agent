export type LanguageCode = "en" | "te" | "hi";

export type ConsentStatus = "granted" | "pending" | "denied" | "revoked";
export type ContactStatus = "active" | "do_not_call" | "archived";

export interface Contact {
  id: string;
  name: string;
  /** E.164, e.g. +919876543210 */
  phone: string;
  /** ISO 3166-1 alpha-2 */
  country: string;
  purpose: string;
  consentStatus: ConsentStatus;
  consentSource: string;
  consentAt: string | null;
  notes: string;
  status: ContactStatus;
  createdAt: string;
  updatedAt: string;
}

export type SessionType = "simulated" | "browser_voice" | "telephone";
export type SessionStatus =
  | "queued"
  | "in_progress"
  | "completed"
  | "failed"
  | "no_answer"
  | "busy"
  | "canceled";

export interface CallSession {
  id: string;
  contactId: string | null;
  contactName: string | null;
  type: SessionType;
  status: SessionStatus;
  outcome: string;
  /** "demo" | "openai" | "simulated" | "twilio" */
  provider: string;
  providerCallId: string | null;
  language: LanguageCode;
  /** True when responses were mock/demo — never a real AI or real phone call. */
  isDemo: boolean;
  startedAt: string;
  endedAt: string | null;
  durationSec: number;
  errorMessage: string | null;
}

export type TranscriptRole = "agent" | "user" | "system";

export interface TranscriptEntry {
  id: string;
  sessionId: string;
  role: TranscriptRole;
  text: string;
  at: string;
}

export interface AppSettings {
  defaultLanguage: LanguageCode;
  /** When true, no real telephone call can ever be placed. */
  testMode: boolean;
  maxCallDurationSec: number;
  agentName: string;
  disclosureMessage: string;
  storeTranscripts: boolean;
  transcriptRetentionDays: number;
}

export interface Metrics {
  totalTestSessions: number;
  completedCalls: number;
  failedSessions: number;
  totalDurationSec: number;
  byType: Record<SessionType, number>;
}

export interface ChatTurn {
  role: "agent" | "user";
  text: string;
}
