import "server-only";
import { createServerClient } from "@supabase/ssr";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";
import { serverEnv } from "../env";

/** Per-request client bound to the signed-in user's cookies (RLS applies). */
export async function createSupabaseServerClient(): Promise<SupabaseClient> {
  const env = serverEnv();
  const cookieStore = await cookies();
  return createServerClient(env.supabaseUrl, env.supabaseKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(toSet) {
        try {
          toSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options));
        } catch {
          /* called from a Server Component; proxy.ts refreshes the session */
        }
      },
    },
  });
}

/**
 * Service-role client. BYPASSES RLS — only for telephone webhooks after the
 * provider signature and per-session token are verified. Never import in client code.
 */
export function createSupabaseAdminClient(): SupabaseClient | null {
  const env = serverEnv();
  if (!env.supabaseUrl || !env.supabaseServiceRoleKey) return null;
  return createClient(env.supabaseUrl, env.supabaseServiceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
