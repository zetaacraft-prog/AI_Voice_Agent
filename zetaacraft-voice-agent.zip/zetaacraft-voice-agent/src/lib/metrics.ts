import type { CallSession, Metrics } from "./types";

export function computeMetrics(sessions: CallSession[]): Metrics {
  const byType = { simulated: 0, browser_voice: 0, telephone: 0 };
  let completedCalls = 0;
  let failedSessions = 0;
  let totalDurationSec = 0;
  for (const s of sessions) {
    byType[s.type]++;
    if (s.status === "completed") completedCalls++;
    if (s.status === "failed") failedSessions++;
    totalDurationSec += s.durationSec || 0;
  }
  return {
    totalTestSessions: byType.simulated + byType.browser_voice,
    completedCalls,
    failedSessions,
    totalDurationSec,
    byType,
  };
}
