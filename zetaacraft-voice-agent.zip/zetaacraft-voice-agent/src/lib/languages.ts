import type { LanguageCode } from "./types";

export interface LanguageConfig {
  code: LanguageCode;
  label: string;
  /** BCP-47 tag for browser speech + telephone speech recognition. */
  speechTag: string;
  /** Only "en" is enabled in the trial MVP; others are wired but gated. */
  enabled: boolean;
  greeting: (agentName: string) => string;
}

export const LANGUAGES: Record<LanguageCode, LanguageConfig> = {
  en: {
    code: "en",
    label: "English",
    speechTag: "en-IN",
    enabled: true,
    greeting: (n) => `Hello! I'm ${n}, an AI voice assistant from Zetaacraft. How can I help you today?`,
  },
  te: {
    code: "te",
    label: "Telugu (planned)",
    speechTag: "te-IN",
    enabled: false,
    greeting: (n) => `నమస్కారం! నేను ${n}, Zetaacraft నుండి AI వాయిస్ అసిస్టెంట్‌ని.`,
  },
  hi: {
    code: "hi",
    label: "Hindi (planned)",
    speechTag: "hi-IN",
    enabled: false,
    greeting: (n) => `नमस्ते! मैं ${n}, Zetaacraft की AI वॉइस असिस्टेंट हूँ।`,
  },
};

export function resolveLanguage(code: string | undefined): LanguageConfig {
  const lang = LANGUAGES[(code ?? "en") as LanguageCode];
  return lang && lang.enabled ? lang : LANGUAGES.en;
}
