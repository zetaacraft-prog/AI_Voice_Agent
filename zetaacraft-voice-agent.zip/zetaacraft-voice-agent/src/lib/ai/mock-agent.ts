import type { ChatTurn } from "../types";
import { isOptOut } from "./agent-prompt";

/**
 * Deterministic, rule-based replies for DEMO mode only. The UI labels every
 * session using this as "Demo – mock AI". It is not a language model.
 */
export function mockAgentReply(message: string, history: ChatTurn[] = []): { text: string; endConversation: boolean } {
  const m = message.toLowerCase();
  const turns = history.filter((h) => h.role === "user").length;

  if (isOptOut(m)) {
    return {
      text: "Understood. I've noted that you don't want to be contacted again. Thank you for your time, goodbye.",
      endConversation: true,
    };
  }
  if (/\b(bye|goodbye|that's all|thank you,? bye)\b/.test(m)) {
    return { text: "Thanks for talking with Zetaacraft. Have a great day, goodbye!", endConversation: true };
  }
  if (/\b(are you (a )?(human|real|robot|bot|ai))\b/.test(m)) {
    return { text: "I'm an AI voice assistant for Zetaacraft, running in demo mode. How can I help?", endConversation: false };
  }
  if (/\b(price|pricing|cost|how much)\b/.test(m)) {
    return {
      text: "Pricing depends on your needs. I can arrange for someone from our team to share a quote. Would you like that?",
      endConversation: false,
    };
  }
  if (/\b(call (me )?(back|later)|busy|another time)\b/.test(m)) {
    return { text: "No problem. What day and time would suit you for a callback?", endConversation: false };
  }
  if (/\b(yes|sure|okay|ok|interested|sounds good)\b/.test(m)) {
    return {
      text: "Great! I'll note your interest and a Zetaacraft team member will follow up. Is there anything specific you'd like them to know?",
      endConversation: false,
    };
  }
  if (/\b(what (do you|does zetaacraft) do|who are you|zetaacraft)\b/.test(m)) {
    return {
      text: "Zetaacraft builds digital products and AI solutions for businesses. Are you exploring something for your team?",
      endConversation: false,
    };
  }
  if (/\b(hello|hi|hey|namaste)\b/.test(m) && turns === 0) {
    return { text: "Hello! Thanks for trying the Zetaacraft voice agent. What would you like to talk about?", endConversation: false };
  }
  const fallbacks = [
    "Thanks for sharing that. Could you tell me a little more?",
    "I see. What would be the most helpful next step for you?",
    "Got it. Would you like a member of our team to follow up with details?",
  ];
  return { text: fallbacks[turns % fallbacks.length], endConversation: false };
}
