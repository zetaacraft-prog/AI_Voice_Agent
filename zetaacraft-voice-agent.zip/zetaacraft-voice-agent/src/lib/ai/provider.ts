import "server-only";
import OpenAI from "openai";
import type { AppSettings, ChatTurn, LanguageCode } from "../types";
import { isOpenAIConfigured, serverEnv } from "../env";
import { buildAgentInstructions } from "./agent-prompt";
import { mockAgentReply } from "./mock-agent";

/**
 * AI provider abstraction. Add new providers (e.g. a Telugu/Hindi-capable speech
 * model) by implementing this interface and registering it in `getAIProvider`.
 */
export interface BrowserVoiceSession {
  kind: "webrtc";
  provider: string;
  clientSecret: string;
  expiresAt: number;
  sdpUrl: string;
  model: string;
}

export interface AIProvider {
  id: "demo" | "openai";
  label: string;
  isDemo: boolean;
  /** Mint a short-lived browser credential. Demo provider returns null (browser speech APIs used). */
  createBrowserSession(opts: {
    settings: AppSettings;
    language: LanguageCode;
    contactPurpose?: string;
  }): Promise<BrowserVoiceSession | null>;
  /** Text turn used by telephone calls (and demo browser voice). */
  generateReply(opts: {
    settings: AppSettings;
    language: LanguageCode;
    history: ChatTurn[];
    message: string;
    channel: "browser" | "telephone";
    contactPurpose?: string;
  }): Promise<{ text: string; endConversation: boolean }>;
}

const demoProvider: AIProvider = {
  id: "demo",
  label: "Demo (mock responses)",
  isDemo: true,
  async createBrowserSession() {
    return null;
  },
  async generateReply({ message, history }) {
    return mockAgentReply(message, history);
  },
};

function openaiProvider(): AIProvider {
  const env = serverEnv();
  const client = new OpenAI({ apiKey: env.openaiApiKey });
  return {
    id: "openai",
    label: "OpenAI Realtime",
    isDemo: false,
    async createBrowserSession({ settings, language, contactPurpose }) {
      // GA Realtime API: POST /v1/realtime/client_secrets (ephemeral key for WebRTC).
      const secret = await client.realtime.clientSecrets.create({
        expires_after: { anchor: "created_at", seconds: 120 },
        session: {
          type: "realtime",
          model: env.openaiRealtimeModel,
          instructions: buildAgentInstructions({ settings, language, channel: "browser", contactPurpose }),
          max_output_tokens: 1024,
          audio: {
            input: {
              transcription: { model: env.openaiTranscribeModel, language },
              turn_detection: { type: "semantic_vad" },
            },
            output: { voice: env.openaiRealtimeVoice },
          },
        },
      });
      return {
        kind: "webrtc",
        provider: "openai",
        clientSecret: secret.value,
        expiresAt: secret.expires_at,
        sdpUrl: "https://api.openai.com/v1/realtime/calls",
        model: env.openaiRealtimeModel,
      };
    },
    async generateReply({ settings, language, history, message, channel, contactPurpose }) {
      const res = await client.responses.create({
        model: env.openaiTextModel,
        instructions: buildAgentInstructions({ settings, language, channel, contactPurpose }),
        input: [
          ...history.map((t) => ({
            role: t.role === "agent" ? ("assistant" as const) : ("user" as const),
            content: t.text,
          })),
          { role: "user" as const, content: message },
        ],
        max_output_tokens: 800,
        store: false,
      });
      const text = res.output_text?.trim() || "Sorry, could you repeat that?";
      return { text, endConversation: false };
    },
  };
}

export function getAIProvider(): AIProvider {
  return isOpenAIConfigured() ? openaiProvider() : demoProvider;
}
