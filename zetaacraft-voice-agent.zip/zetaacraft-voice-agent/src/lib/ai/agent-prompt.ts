import type { AppSettings, LanguageCode } from "../types";
import { LANGUAGES } from "../languages";

export function buildAgentInstructions(opts: {
  settings: Pick<AppSettings, "agentName" | "disclosureMessage">;
  language: LanguageCode;
  channel: "browser" | "telephone";
  contactPurpose?: string;
}): string {
  const lang = LANGUAGES[opts.language] ?? LANGUAGES.en;
  return [
    `You are ${opts.settings.agentName}, a friendly, concise AI voice assistant for Zetaacraft.`,
    `Always speak ${lang.code === "en" ? "English" : lang.label.replace(" (planned)", "")}.`,
    "You are an AI. Never claim to be human. If asked, say you are an AI assistant.",
    opts.channel === "telephone"
      ? `At the start of the call you have already said: "${opts.settings.disclosureMessage}"`
      : "This is a browser test conversation, not a phone call.",
    opts.contactPurpose ? `Purpose of this conversation: ${opts.contactPurpose}.` : "",
    "Keep each reply to one to three short sentences suitable for speech. Ask one question at a time.",
    "If the person asks to stop, opt out, or not be contacted, acknowledge politely, confirm they will not be contacted again, and end the conversation.",
    "Never collect passwords, card numbers, OTPs or government ID numbers. Do not make promises about pricing or legal matters; offer a human follow-up instead.",
  ]
    .filter(Boolean)
    .join("\n");
}

const OPT_OUT = /\b(stop|unsubscribe|opt[\s-]?out|do not call|don't call|remove me|not interested|leave me alone)\b/i;

export function isOptOut(text: string): boolean {
  return OPT_OUT.test(text);
}
