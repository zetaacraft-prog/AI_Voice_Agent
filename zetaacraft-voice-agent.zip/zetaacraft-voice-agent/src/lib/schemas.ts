import { z } from "zod";
import { parsePhone } from "./phone";

const trimmed = (max: number) => z.string().trim().max(max);

export const languageSchema = z.enum(["en", "te", "hi"]);
export const consentStatusSchema = z.enum(["granted", "pending", "denied", "revoked"]);
export const contactStatusSchema = z.enum(["active", "do_not_call", "archived"]);

export const contactInputSchema = z
  .object({
    name: trimmed(120).min(1, "Name is required"),
    phone: z.string().trim().min(1, "Phone is required").max(32),
    country: z
      .string()
      .trim()
      .toUpperCase()
      .regex(/^[A-Z]{2}$/, "Use a 2-letter ISO country code")
      .optional(),
    purpose: trimmed(300).default(""),
    consentStatus: consentStatusSchema.default("pending"),
    consentSource: trimmed(200).default(""),
    notes: trimmed(2000).default(""),
    status: contactStatusSchema.default("active"),
  })
  .transform((v, ctx) => {
    const parsed = parsePhone(v.phone);
    if (!parsed) {
      ctx.addIssue({
        code: "custom",
        path: ["phone"],
        message: "Enter a valid number with country code, e.g. +91 98765 43210",
      });
      return z.NEVER;
    }
    if (v.consentStatus === "granted" && !v.consentSource) {
      ctx.addIssue({
        code: "custom",
        path: ["consentSource"],
        message: "Record where consent came from (e.g. web form, signed agreement)",
      });
      return z.NEVER;
    }
    const country = v.country ?? parsed.country ?? "";
    if (parsed.country && v.country && parsed.country !== v.country) {
      ctx.addIssue({
        code: "custom",
        path: ["country"],
        message: `Number belongs to ${parsed.country}, not ${v.country}`,
      });
      return z.NEVER;
    }
    return { ...v, phone: parsed.e164, country };
  });
export type ContactInput = z.output<typeof contactInputSchema>;

export const settingsSchema = z.object({
  defaultLanguage: languageSchema,
  testMode: z.boolean(),
  maxCallDurationSec: z.number().int().min(30).max(1800),
  agentName: trimmed(60).min(1),
  disclosureMessage: trimmed(500).min(10, "A disclosure message is required"),
  storeTranscripts: z.boolean(),
  transcriptRetentionDays: z.number().int().min(1).max(365),
});
export const settingsPatchSchema = settingsSchema.partial();

export const uuidSchema = z.uuid();

export const createSessionSchema = z.object({
  type: z.literal("browser_voice"),
  contactId: z.uuid().nullable().optional(),
  language: languageSchema.default("en"),
});

export const transcriptAppendSchema = z.object({
  entries: z
    .array(
      z.object({
        role: z.enum(["agent", "user", "system"]),
        text: trimmed(4000).min(1),
      }),
    )
    .min(1)
    .max(50),
});

export const endSessionSchema = z.object({
  status: z.enum(["completed", "failed", "canceled"]),
  outcome: trimmed(300).default(""),
  errorMessage: trimmed(500).nullable().optional(),
});

export const simulateCallSchema = z.object({
  contactId: z.uuid(),
  scenario: z.enum(["interested", "callback", "not_interested", "no_answer", "opt_out"]).optional(),
});

export const liveCallSchema = z.object({
  contactId: z.uuid(),
  /** User must type the last 4 digits of the destination number to confirm. */
  confirmLast4: z.string().regex(/^\d{4}$/),
  acknowledgedCharges: z.literal(true),
});

export const demoReplySchema = z.object({
  history: z
    .array(z.object({ role: z.enum(["agent", "user"]), text: trimmed(2000) }))
    .max(40),
  message: trimmed(2000).min(1),
  language: languageSchema.default("en"),
});
