import { NextResponse } from "next/server";
import { publicConfigStatus } from "@/lib/env";
import { handle } from "@/lib/api";

export const dynamic = "force-dynamic";

/** Non-secret configuration status for the dashboard (booleans + labels only). */
export const GET = handle(async () => NextResponse.json(publicConfigStatus()));
