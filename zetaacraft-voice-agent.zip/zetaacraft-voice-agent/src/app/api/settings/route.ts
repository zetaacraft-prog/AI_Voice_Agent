import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { settingsPatchSchema } from "@/lib/schemas";
import { serverEnv } from "@/lib/env";
import { LANGUAGES } from "@/lib/languages";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const { repo, mode } = await getRequestContext();
  return NextResponse.json({ settings: await repo.getSettings(), mode });
});

export const PUT = handle(async (req: Request) => {
  const { repo, mode } = await getRequestContext();
  const patch = await parseBody(req, settingsPatchSchema);
  if (patch.defaultLanguage && !LANGUAGES[patch.defaultLanguage].enabled)
    return jsonError(400, `${LANGUAGES[patch.defaultLanguage].label} is not available yet in this MVP.`);
  if (patch.testMode === false) {
    if (mode !== "supabase") return jsonError(409, "Live mode requires Supabase mode with sign-in. Demo mode is always test mode.");
    if (!serverEnv().liveCallsEnabled) return jsonError(409, "Live mode is disabled on the server (LIVE_CALLS_ENABLED is not 'true').");
  }
  return NextResponse.json({ settings: await repo.updateSettings(patch) });
});
