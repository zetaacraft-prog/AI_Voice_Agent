import { NextResponse } from "next/server";
import { z } from "zod";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { getAIProvider } from "@/lib/ai/provider";
import { rateLimit } from "@/lib/rate-limit";

/**
 * Mints a short-lived (120s) client secret for a browser WebRTC session.
 * The long-lived API key never leaves the server.
 */
export const POST = handle(async (req: Request) => {
  const ctx = await getRequestContext();
  const rl = rateLimit(`rt:${ctx.user?.id ?? "demo"}`, 10, 60_000);
  if (!rl.ok) return jsonError(429, `Too many voice sessions. Try again in ${rl.retryAfterSec}s.`);
  const { sessionId } = await parseBody(req, z.object({ sessionId: z.uuid() }));
  const session = await ctx.repo.getSession(sessionId);
  if (!session || session.type !== "browser_voice" || session.status !== "in_progress")
    return jsonError(409, "Start a browser voice session first.");

  const ai = getAIProvider();
  const settings = await ctx.repo.getSettings();
  const contact = session.contactId ? await ctx.repo.getContact(session.contactId) : null;
  try {
    const browser = await ai.createBrowserSession({ settings, language: session.language, contactPurpose: contact?.purpose });
    if (!browser) return NextResponse.json({ provider: "demo" });
    return NextResponse.json({ ...browser, maxDurationSec: settings.maxCallDurationSec });
  } catch (err) {
    console.error("[realtime-token]", err instanceof Error ? err.message : err);
    return jsonError(502, "Could not create a voice session with the AI provider. Check OPENAI_API_KEY, model access and billing.");
  }
});
