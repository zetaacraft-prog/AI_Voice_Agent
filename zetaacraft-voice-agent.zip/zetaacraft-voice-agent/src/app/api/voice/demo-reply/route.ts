import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { demoReplySchema } from "@/lib/schemas";
import { mockAgentReply } from "@/lib/ai/mock-agent";
import { rateLimit } from "@/lib/rate-limit";

/** DEMO ONLY: rule-based reply for the free browser-speech test mode. Not an AI model. */
export const POST = handle(async (req: Request) => {
  const ctx = await getRequestContext();
  const rl = rateLimit(`demo:${ctx.user?.id ?? "demo"}`, 120, 60_000);
  if (!rl.ok) return jsonError(429, "Slow down a little.");
  const { message, history } = await parseBody(req, demoReplySchema);
  return NextResponse.json({ ...mockAgentReply(message, history), demo: true });
});
