import { NextResponse } from "next/server";
import { createHash, randomBytes } from "node:crypto";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { liveCallSchema } from "@/lib/schemas";
import { evaluateGateForRequest } from "@/lib/safety/gate-context";
import { getLiveTelecomProvider } from "@/lib/telecom";
import { serverEnv } from "@/lib/env";
import { rateLimit } from "@/lib/rate-limit";

/** Places a REAL, BILLED telephone call — only after every safety gate passes. */
export const POST = handle(async (req: Request) => {
  const ctx = await getRequestContext();
  const rl = rateLimit(`live:${ctx.user?.id ?? "demo"}`, 3, 60_000);
  if (!rl.ok) return jsonError(429, `Too many call attempts. Try again in ${rl.retryAfterSec}s.`);
  const body = await parseBody(req, liveCallSchema);
  const contact = await ctx.repo.getContact(body.contactId);

  const gate = await evaluateGateForRequest(ctx, contact, body);
  if (!gate.allowed || !contact) {
    return NextResponse.json({ error: "Live call blocked by safety checks.", reasons: gate.reasons }, { status: 403 });
  }

  const provider = getLiveTelecomProvider();
  if (!provider || !provider.realNetwork) return jsonError(503, "Telecom provider is not configured.");
  const callerId = await provider.verifyCallerId();
  if (!callerId.ok) return jsonError(409, callerId.message);

  const settings = await ctx.repo.getSettings();
  const webhookToken = randomBytes(24).toString("base64url");
  const session = await ctx.repo.createSession({
    contactId: contact.id,
    contactName: contact.name,
    type: "telephone",
    status: "queued",
    outcome: "",
    provider: provider.id,
    providerCallId: null,
    language: settings.defaultLanguage,
    isDemo: false,
    startedAt: new Date().toISOString(),
    endedAt: null,
    durationSec: 0,
    errorMessage: null,
    webhookTokenHash: createHash("sha256").update(webhookToken).digest("hex"),
  });

  try {
    const { providerCallId } = await provider.placeCall({
      to: contact.phone,
      sessionId: session.id,
      webhookToken,
      maxDurationSec: settings.maxCallDurationSec,
      baseUrl: serverEnv().appBaseUrl,
    });
    const updated = await ctx.repo.updateSession(session.id, { providerCallId });
    return NextResponse.json({ session: updated }, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Provider error";
    await ctx.repo.updateSession(session.id, {
      status: "failed",
      outcome: "Provider rejected the call",
      errorMessage: message.slice(0, 500),
      endedAt: new Date().toISOString(),
    });
    return jsonError(502, `Telecom provider rejected the call: ${message}`);
  }
});
