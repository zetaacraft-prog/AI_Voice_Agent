import { NextResponse } from "next/server";
import { z } from "zod";
import { getRequestContext } from "@/lib/data";
import { handle, parseBody } from "@/lib/api";
import { evaluateGateForRequest } from "@/lib/safety/gate-context";

/** Dry-run of the live-call gate (excluding the per-call confirmation) so the UI can explain what is missing. */
export const POST = handle(async (req: Request) => {
  const ctx = await getRequestContext();
  const { contactId } = await parseBody(req, z.object({ contactId: z.uuid() }));
  const contact = await ctx.repo.getContact(contactId);
  const result = await evaluateGateForRequest(ctx, contact, {
    confirmLast4: contact?.phone.slice(-4) ?? "",
    acknowledgedCharges: true,
  });
  return NextResponse.json(result);
});
