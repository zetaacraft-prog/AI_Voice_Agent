import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { simulateCallSchema } from "@/lib/schemas";
import { buildSimulatedCall, pickScenario } from "@/lib/simulation/simulated-call";
import { simulatedTelecom } from "@/lib/telecom/simulated";
import { rateLimit } from "@/lib/rate-limit";

/**
 * Runs a fully SIMULATED call. The simulated telecom provider never dials.
 * Works for any contact regardless of consent, because nobody is contacted.
 */
export const POST = handle(async (req: Request) => {
  const ctx = await getRequestContext();
  const rl = rateLimit(`sim:${ctx.user?.id ?? "demo"}`, 30, 60_000);
  if (!rl.ok) return jsonError(429, `Too many simulations. Try again in ${rl.retryAfterSec}s.`);
  const body = await parseBody(req, simulateCallSchema);
  const contact = await ctx.repo.getContact(body.contactId);
  if (!contact) return jsonError(404, "Contact not found");
  const settings = await ctx.repo.getSettings();

  const scenario = body.scenario ?? pickScenario(`${contact.id}:${Date.now()}`);
  const sim = buildSimulatedCall(contact, settings, scenario);
  const startedAt = new Date();
  const session = await ctx.repo.createSession({
    contactId: contact.id,
    contactName: contact.name,
    type: "simulated",
    status: "in_progress",
    outcome: "",
    provider: simulatedTelecom.id,
    providerCallId: null,
    language: settings.defaultLanguage,
    isDemo: true,
    startedAt: startedAt.toISOString(),
    endedAt: null,
    durationSec: 0,
    errorMessage: null,
  });
  const { providerCallId } = await simulatedTelecom.placeCall({
    to: contact.phone,
    sessionId: session.id,
    webhookToken: "",
    maxDurationSec: settings.maxCallDurationSec,
    baseUrl: "",
  });
  if (settings.storeTranscripts) {
    await ctx.repo.appendTranscript(
      session.id,
      sim.lines.map((l) => ({ role: l.role, text: l.text, at: new Date(startedAt.getTime() + l.offsetSec * 1000).toISOString() })),
    );
  }
  const updated = await ctx.repo.updateSession(session.id, {
    providerCallId,
    status: sim.status,
    outcome: sim.outcome,
    durationSec: sim.durationSec,
    endedAt: new Date(startedAt.getTime() + Math.max(sim.durationSec, 30) * 1000).toISOString(),
  });
  if (sim.markDoNotCall) {
    await ctx.repo.updateContact(contact.id, { status: "do_not_call", consentStatus: "revoked" });
  }
  return NextResponse.json({ session: updated, lines: sim.lines, scenario }, { status: 201 });
});
