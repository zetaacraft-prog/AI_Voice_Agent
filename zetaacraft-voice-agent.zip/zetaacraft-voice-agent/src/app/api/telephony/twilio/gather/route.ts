import twilio from "twilio";
import { gatherUrl, hangupTwiml, twimlResponse, verifyTwilioWebhook } from "@/lib/telecom/twilio-webhook";
import { webhookAppendTranscript, webhookListTranscript, webhookMarkDoNotCall, webhookUpdateSession } from "@/lib/data/webhook-store";
import { getAIProvider } from "@/lib/ai/provider";
import { isOptOut } from "@/lib/ai/agent-prompt";
import { mockAgentReply } from "@/lib/ai/mock-agent";
import { LANGUAGES } from "@/lib/languages";
import type { ChatTurn } from "@/lib/types";

const MAX_TURNS = 10;
const AI_TIMEOUT_MS = 8000; // Twilio waits ~15s for a webhook response.

/** Each caller utterance arrives here (Twilio <Gather input="speech">). */
export async function POST(req: Request) {
  const v = await verifyTwilioWebhook(req);
  if (!v.ok) return new Response("Forbidden", { status: v.status });
  const { ctx, params } = v;
  const speech = (params.SpeechResult ?? "").trim().slice(0, 1000);
  const lang = LANGUAGES[ctx.session.language] ?? LANGUAGES.en;

  if (!speech) return hangupTwiml("Sorry, I couldn't hear you. Goodbye.");
  await webhookAppendTranscript(ctx, [{ role: "user", text: speech }]);

  if (isOptOut(speech)) {
    const bye = "Understood. You won't be contacted again. Goodbye.";
    await webhookMarkDoNotCall(ctx);
    await webhookAppendTranscript(ctx, [{ role: "agent", text: bye }]);
    await webhookUpdateSession(ctx, { outcome: "Opted out — marked do-not-call" });
    return hangupTwiml(bye);
  }

  const transcript = await webhookListTranscript(ctx);
  const history: ChatTurn[] = transcript
    .filter((t) => t.role !== "system")
    .slice(0, -1)
    .map((t) => ({ role: t.role as ChatTurn["role"], text: t.text }));
  const userTurns = transcript.filter((t) => t.role === "user").length;

  let reply: { text: string; endConversation: boolean };
  if (userTurns >= MAX_TURNS) {
    reply = { text: "Thank you so much for your time. A member of our team will follow up. Goodbye!", endConversation: true };
  } else {
    try {
      reply = await Promise.race([
        getAIProvider().generateReply({
          settings: ctx.settings,
          language: ctx.session.language,
          history,
          message: speech,
          channel: "telephone",
          contactPurpose: ctx.contact?.purpose,
        }),
        new Promise<never>((_, rej) => setTimeout(() => rej(new Error("AI timeout")), AI_TIMEOUT_MS)),
      ]);
    } catch (err) {
      console.error("[twilio/gather]", err instanceof Error ? err.message : err);
      reply = mockAgentReply(speech, history);
    }
  }

  await webhookAppendTranscript(ctx, [{ role: "agent", text: reply.text }]);
  if (reply.endConversation) return hangupTwiml(reply.text);

  const vr = new twilio.twiml.VoiceResponse();
  const gather = vr.gather({
    input: ["speech"],
    action: gatherUrl(ctx, req),
    method: "POST",
    speechTimeout: "auto",
    language: lang.speechTag as never,
  });
  gather.say({ language: lang.speechTag as never }, reply.text);
  vr.say({ language: lang.speechTag as never }, "I didn't catch that. Thank you for your time. Goodbye.");
  vr.hangup();
  return twimlResponse(vr);
}
