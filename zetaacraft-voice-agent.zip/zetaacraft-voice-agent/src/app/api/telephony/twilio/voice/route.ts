import twilio from "twilio";
import { gatherUrl, hangupTwiml, twimlResponse, verifyTwilioWebhook } from "@/lib/telecom/twilio-webhook";
import { webhookAppendTranscript, webhookUpdateSession } from "@/lib/data/webhook-store";
import { LANGUAGES } from "@/lib/languages";

/** Twilio fetches this when the callee answers: disclosure first, then listen. */
export async function POST(req: Request) {
  const v = await verifyTwilioWebhook(req);
  if (!v.ok) return new Response("Forbidden", { status: v.status });
  const { ctx, params } = v;

  // Re-check consent at answer time in case it changed after dialing.
  if (!ctx.contact || ctx.contact.consentStatus !== "granted" || ctx.contact.status !== "active") {
    await webhookUpdateSession(ctx, { status: "canceled", outcome: "Ended: consent no longer valid" });
    return hangupTwiml();
  }

  const lang = LANGUAGES[ctx.session.language] ?? LANGUAGES.en;
  const greeting = `How are you today? I'm calling about ${ctx.contact.purpose || "a quick follow-up"}. Is now a good time to talk?`;
  await webhookUpdateSession(ctx, { status: "in_progress", providerCallId: params.CallSid ?? ctx.session.providerCallId });
  await webhookAppendTranscript(ctx, [
    { role: "system", text: "Live telephone call answered." },
    { role: "agent", text: ctx.settings.disclosureMessage },
    { role: "agent", text: greeting },
  ]);

  const vr = new twilio.twiml.VoiceResponse();
  // Twilio's TwiML typings use a closed union of language tags; our tags are valid members.
  const sayLang = lang.speechTag as never;
  vr.say({ language: sayLang }, ctx.settings.disclosureMessage);
  const gather = vr.gather({
    input: ["speech"],
    action: gatherUrl(ctx, req),
    method: "POST",
    speechTimeout: "auto",
    language: sayLang,
  });
  gather.say({ language: sayLang }, greeting);
  vr.say({ language: sayLang }, "I didn't catch that. Thank you for your time. Goodbye.");
  vr.hangup();
  return twimlResponse(vr);
}
