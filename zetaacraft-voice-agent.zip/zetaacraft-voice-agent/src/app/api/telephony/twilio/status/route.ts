import { verifyTwilioWebhook } from "@/lib/telecom/twilio-webhook";
import { webhookDeleteTranscript, webhookUpdateSession } from "@/lib/data/webhook-store";
import type { SessionStatus } from "@/lib/types";

const STATUS_MAP: Record<string, SessionStatus> = {
  queued: "queued",
  initiated: "queued",
  ringing: "queued",
  "in-progress": "in_progress",
  completed: "completed",
  busy: "busy",
  "no-answer": "no_answer",
  failed: "failed",
  canceled: "canceled",
};
const TERMINAL = new Set<SessionStatus>(["completed", "busy", "no_answer", "failed", "canceled"]);

/** Twilio call status callbacks (initiated → ringing → answered → completed). */
export async function POST(req: Request) {
  const v = await verifyTwilioWebhook(req);
  if (!v.ok) return new Response("Forbidden", { status: v.status });
  const { ctx, params } = v;
  const status = STATUS_MAP[params.CallStatus ?? ""];
  if (!status) return new Response(null, { status: 204 });

  const terminal = TERMINAL.has(status);
  await webhookUpdateSession(ctx, {
    status,
    ...(terminal
      ? {
          endedAt: new Date().toISOString(),
          durationSec: Math.max(0, Number(params.CallDuration) || 0),
          outcome: ctx.session.outcome || (status === "completed" ? "Call completed" : `Call ${params.CallStatus}`),
        }
      : {}),
  });
  // Transcript is kept during the call for conversation context; drop it afterwards if disabled.
  if (terminal && !ctx.settings.storeTranscripts) await webhookDeleteTranscript(ctx);
  return new Response(null, { status: 204 });
}
