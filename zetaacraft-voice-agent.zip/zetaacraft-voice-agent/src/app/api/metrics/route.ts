import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle } from "@/lib/api";
import { computeMetrics } from "@/lib/metrics";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const { repo } = await getRequestContext();
  const [sessions, settings] = await Promise.all([repo.listSessions(1000), repo.getSettings()]);
  return NextResponse.json({ metrics: computeMetrics(sessions), testMode: settings.testMode, recent: sessions.slice(0, 5) });
});
