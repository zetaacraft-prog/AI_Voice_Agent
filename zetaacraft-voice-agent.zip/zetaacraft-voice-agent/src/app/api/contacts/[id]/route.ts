import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { contactInputSchema, uuidSchema } from "@/lib/schemas";

type Ctx = { params: Promise<{ id: string }> };

async function idFrom(ctx: Ctx) {
  const { id } = await ctx.params;
  return uuidSchema.safeParse(id).success ? id : null;
}

export const GET = handle(async (_req: Request, ctx: Ctx) => {
  const id = await idFrom(ctx);
  if (!id) return jsonError(400, "Invalid id");
  const { repo } = await getRequestContext();
  const contact = await repo.getContact(id);
  return contact ? NextResponse.json({ contact }) : jsonError(404, "Contact not found");
});

export const PUT = handle(async (req: Request, ctx: Ctx) => {
  const id = await idFrom(ctx);
  if (!id) return jsonError(400, "Invalid id");
  const { repo } = await getRequestContext();
  const input = await parseBody(req, contactInputSchema);
  const contact = await repo.updateContact(id, input);
  return contact ? NextResponse.json({ contact }) : jsonError(404, "Contact not found");
});

export const DELETE = handle(async (_req: Request, ctx: Ctx) => {
  const id = await idFrom(ctx);
  if (!id) return jsonError(400, "Invalid id");
  const { repo } = await getRequestContext();
  return (await repo.deleteContact(id)) ? new NextResponse(null, { status: 204 }) : jsonError(404, "Contact not found");
});
