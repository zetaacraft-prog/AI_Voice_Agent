import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, parseBody } from "@/lib/api";
import { contactInputSchema } from "@/lib/schemas";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const { repo } = await getRequestContext();
  return NextResponse.json({ contacts: await repo.listContacts() });
});

export const POST = handle(async (req: Request) => {
  const { repo } = await getRequestContext();
  const input = await parseBody(req, contactInputSchema);
  return NextResponse.json({ contact: await repo.createContact(input) }, { status: 201 });
});
