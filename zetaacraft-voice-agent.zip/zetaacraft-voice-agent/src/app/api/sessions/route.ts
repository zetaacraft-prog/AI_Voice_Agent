import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { createSessionSchema } from "@/lib/schemas";
import { getAIProvider } from "@/lib/ai/provider";
import { resolveLanguage } from "@/lib/languages";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const { repo } = await getRequestContext();
  return NextResponse.json({ sessions: await repo.listSessions() });
});

/** Starts a browser voice session record. Media flows browser <-> AI provider, not through here. */
export const POST = handle(async (req: Request) => {
  const { repo } = await getRequestContext();
  const body = await parseBody(req, createSessionSchema);
  const contact = body.contactId ? await repo.getContact(body.contactId) : null;
  if (body.contactId && !contact) return jsonError(404, "Contact not found");
  const ai = getAIProvider();
  const session = await repo.createSession({
    contactId: contact?.id ?? null,
    contactName: contact?.name ?? null,
    type: "browser_voice",
    status: "in_progress",
    outcome: "",
    provider: ai.id,
    providerCallId: null,
    language: resolveLanguage(body.language).code,
    isDemo: ai.isDemo,
    startedAt: new Date().toISOString(),
    endedAt: null,
    durationSec: 0,
    errorMessage: null,
  });
  return NextResponse.json({ session }, { status: 201 });
});
