import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { endSessionSchema, uuidSchema } from "@/lib/schemas";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!uuidSchema.safeParse(id).success) return jsonError(400, "Invalid id");
  const { repo } = await getRequestContext();
  const session = await repo.getSession(id);
  if (!session) return jsonError(404, "Session not found");
  if (session.type !== "browser_voice") return jsonError(409, "Only browser sessions can be ended here");
  if (session.status !== "in_progress") return NextResponse.json({ session });
  const body = await parseBody(req, endSessionSchema);
  const settings = await repo.getSettings();
  const endedAt = new Date();
  const durationSec = Math.min(
    settings.maxCallDurationSec,
    Math.max(0, Math.round((endedAt.getTime() - new Date(session.startedAt).getTime()) / 1000)),
  );
  const updated = await repo.updateSession(id, {
    status: body.status,
    outcome: body.outcome || (body.status === "completed" ? "Conversation ended" : body.status),
    errorMessage: body.errorMessage ?? null,
    endedAt: endedAt.toISOString(),
    durationSec,
  });
  return NextResponse.json({ session: updated });
});
