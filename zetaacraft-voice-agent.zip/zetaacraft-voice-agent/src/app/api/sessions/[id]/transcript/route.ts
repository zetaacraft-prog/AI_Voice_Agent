import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError, parseBody } from "@/lib/api";
import { transcriptAppendSchema, uuidSchema } from "@/lib/schemas";

type Ctx = { params: Promise<{ id: string }> };

export const POST = handle(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!uuidSchema.safeParse(id).success) return jsonError(400, "Invalid id");
  const { repo } = await getRequestContext();
  const session = await repo.getSession(id);
  if (!session) return jsonError(404, "Session not found");
  if (session.type !== "browser_voice" || session.status !== "in_progress")
    return jsonError(409, "Transcript can only be appended to an active browser session");
  const { entries } = await parseBody(req, transcriptAppendSchema);
  const settings = await repo.getSettings();
  if (settings.storeTranscripts) await repo.appendTranscript(id, entries);
  return NextResponse.json({ stored: settings.storeTranscripts });
});
