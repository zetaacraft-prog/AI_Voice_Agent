import { NextResponse } from "next/server";
import { getRequestContext } from "@/lib/data";
import { handle, jsonError } from "@/lib/api";
import { uuidSchema } from "@/lib/schemas";

type Ctx = { params: Promise<{ id: string }> };

/** Session detail. Transcript is only returned when ?transcript=1 is requested explicitly. */
export const GET = handle(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!uuidSchema.safeParse(id).success) return jsonError(400, "Invalid id");
  const { repo } = await getRequestContext();
  const session = await repo.getSession(id);
  if (!session) return jsonError(404, "Session not found");
  const settings = await repo.getSettings();
  const wantTranscript = new URL(req.url).searchParams.get("transcript") === "1";
  let transcript = null;
  if (wantTranscript && settings.storeTranscripts) {
    const cutoff = new Date(Date.now() - settings.transcriptRetentionDays * 86_400_000).toISOString();
    await repo.purgeTranscriptsBefore(cutoff);
    transcript = await repo.listTranscript(id);
  }
  return NextResponse.json({
    session,
    transcript,
    transcriptPolicy: { stored: settings.storeTranscripts, retentionDays: settings.transcriptRetentionDays },
  });
});
