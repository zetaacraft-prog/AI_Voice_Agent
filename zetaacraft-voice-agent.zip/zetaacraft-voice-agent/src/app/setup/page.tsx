import Link from "next/link";
import { publicConfigStatus } from "@/lib/env";

export const dynamic = "force-dynamic";

function Step({ done, title, children }: { done: boolean; title: string; children: React.ReactNode }) {
  return (
    <section className="card">
      <div className="mb-2 flex items-center gap-2">
        <span className={`flex h-5 w-5 items-center justify-center rounded-full text-xs text-white ${done ? "bg-emerald-500" : "bg-slate-300"}`}>
          {done ? "✓" : ""}
        </span>
        <h2 className="font-semibold">{title}</h2>
      </div>
      <div className="space-y-2 text-sm text-slate-600 [&_code]:rounded [&_code]:bg-slate-100 [&_code]:px-1 [&_code]:py-0.5 [&_code]:text-xs [&_pre]:overflow-x-auto [&_pre]:rounded-lg [&_pre]:bg-slate-900 [&_pre]:p-3 [&_pre]:text-xs [&_pre]:text-slate-100">
        {children}
      </div>
    </section>
  );
}

export default function SetupPage() {
  const s = publicConfigStatus();
  return (
    <main className="mx-auto max-w-3xl space-y-4 p-4 sm:p-8">
      <Link href="/" className="text-sm text-indigo-600 hover:underline">
        ← Back to dashboard
      </Link>
      <h1 className="text-2xl font-semibold">Setup guide</h1>
      <p className="text-sm text-slate-500">
        Everything works in free demo mode without any accounts. Each step below is optional and unlocks more. Secrets go in <code>.env.local</code>{" "}
        (local) or Vercel environment variables — never in the browser.
      </p>

      <Step done title="1. Free demo mode (no setup)">
        <p>Explore the dashboard, add contacts, run simulated calls and talk to the mock agent with your browser&apos;s speech engine.</p>
        <p>Demo data lives in memory and in <code>.data/demo-store.json</code> during local development.</p>
      </Step>

      <Step done={s.dataMode === "supabase"} title="2. Supabase (database + login)">
        <p>Create a Supabase project, run <code>supabase/migrations/0001_init.sql</code> in the SQL editor, then set:</p>
        <pre>{`NEXT_PUBLIC_SUPABASE_URL=https://<project>.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=<publishable or anon key>
SUPABASE_SERVICE_ROLE_KEY=<service role key>  # server only, for phone webhooks`}</pre>
        <p>Restart the dev server. You&apos;ll be asked to sign in; every row is protected by Row Level Security.</p>
      </Step>

      <Step done={s.ai.configured} title="3. Real AI voice (OpenAI Realtime)">
        <p>
          Needs an OpenAI API account with billing (a Claude or ChatGPT consumer subscription does <strong>not</strong> include API access). Browser
          audio flows directly between your browser and OpenAI over WebRTC using a 2-minute token minted by the server.
        </p>
        <pre>{`AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_REALTIME_MODEL=gpt-realtime`}</pre>
      </Step>

      <Step done={s.telecom.configured && s.telecom.liveCallsEnabledByServer} title="4. Real phone calls (optional, paid)">
        <p>
          Real calls are billed per minute by Twilio, and international rates vary by destination. Twilio trial accounts can only call numbers you have
          verified and play a trial notice.
        </p>
        <ol className="list-decimal space-y-1 pl-5">
          <li>Create a Twilio account and either buy a voice number or verify your own number under <em>Phone Numbers → Verified Caller IDs</em>.</li>
          <li>Enable the destination countries under <em>Voice → Settings → Geo permissions</em>.</li>
          <li>Expose the app over https (Vercel, or <code>ngrok http 3000</code> locally) and set <code>APP_BASE_URL</code>.</li>
          <li>Configure Supabase (step 2) — live calls require sign-in.</li>
        </ol>
        <pre>{`LIVE_CALLS_ENABLED=true
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_CALLER_ID=+91XXXXXXXXXX   # Twilio number or verified caller ID
LIVE_CALL_ALLOWED_COUNTRIES=IN,US
APP_BASE_URL=https://your-app.vercel.app`}</pre>
        <p>Then turn Test mode off in Settings. Each call still requires granted consent and typing the last 4 digits to confirm.</p>
      </Step>

      <section className="card text-sm">
        <h2 className="mb-2 font-semibold">Current status</h2>
        <ul className="space-y-1 text-slate-600">
          <li>Data: {s.dataMode}</li>
          <li>AI: {s.ai.configured ? `OpenAI (${s.ai.realtimeModel})` : "demo"}</li>
          <li>Telecom: {s.telecom.configured ? "Twilio configured" : "not configured"}</li>
          <li>Live calls allowed by server: {s.telecom.liveCallsEnabledByServer ? "yes" : "no"}</li>
        </ul>
      </section>
    </main>
  );
}
