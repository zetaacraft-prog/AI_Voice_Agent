"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { useApp } from "@/components/app-context";
import { Badge, ErrorBanner, PageHeader } from "@/components/ui";
import { api } from "@/lib/client/api";
import {
  DemoSpeechEngine,
  OpenAIRealtimeEngine,
  type EngineState,
  type RealtimeToken,
  type VoiceEngine,
} from "@/lib/client/voice-engines";
import { LANGUAGES, resolveLanguage } from "@/lib/languages";
import type { CallSession, Contact } from "@/lib/types";

interface Line {
  id: number;
  role: "agent" | "user";
  text: string;
  final: boolean;
}

const STATE_LABEL: Record<EngineState, string> = {
  idle: "Not connected",
  requesting_mic: "Waiting for microphone permission…",
  connecting: "Connecting to voice provider…",
  live: "Live",
  ending: "Ending…",
  error: "Error",
};

export default function AgentPage() {
  const { status, settings } = useApp();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [contactId, setContactId] = useState("");
  const [state, setState] = useState<EngineState>("idle");
  const [error, setError] = useState<string | null>(null);
  const [lines, setLines] = useState<Line[]>([]);
  const [muted, setMuted] = useState(false);
  const [level, setLevel] = useState(0);
  const [userSpeaking, setUserSpeaking] = useState(false);
  const [agentSpeaking, setAgentSpeaking] = useState(false);
  const [engineLabel, setEngineLabel] = useState<string | null>(null);
  const [isDemo, setIsDemo] = useState(true);
  const [elapsed, setElapsed] = useState(0);
  const [typed, setTyped] = useState("");
  const [canRecognize, setCanRecognize] = useState(true);

  const engine = useRef<VoiceEngine | null>(null);
  const session = useRef<CallSession | null>(null);
  const lineId = useRef(0);
  const timer = useRef<number | null>(null);
  const transcriptEnd = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api<{ contacts: Contact[] }>("/api/contacts")
      .then((r) => setContacts(r.contacts))
      .catch(() => {});
    // eslint-disable-next-line react-hooks/set-state-in-effect -- browser capability check after mount
    setCanRecognize(DemoSpeechEngine.supportsRecognition());
  }, []);

  useEffect(() => {
    transcriptEnd.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [lines]);

  const persist = useCallback((role: "agent" | "user", text: string) => {
    const s = session.current;
    if (!s) return;
    void api(`/api/sessions/${s.id}/transcript`, { method: "POST", json: { entries: [{ role, text }] } }).catch(() => {});
  }, []);

  const onTranscript = useCallback(
    (role: "agent" | "user", text: string, final: boolean) => {
      setLines((prev) => {
        const last = prev[prev.length - 1];
        if (last && last.role === role && !last.final) {
          return [...prev.slice(0, -1), { ...last, text, final }];
        }
        return [...prev, { id: ++lineId.current, role, text, final }];
      });
      if (final) persist(role, text);
    },
    [persist],
  );

  const end = useCallback(async (outcome: "completed" | "failed" | "canceled", detail?: string) => {
    const e = engine.current;
    engine.current = null;
    e?.stop();
    if (timer.current) window.clearInterval(timer.current);
    timer.current = null;
    setUserSpeaking(false);
    setAgentSpeaking(false);
    setLevel(0);
    const s = session.current;
    session.current = null;
    if (s) {
      setState("ending");
      await api(`/api/sessions/${s.id}/end`, {
        method: "POST",
        json: { status: outcome, outcome: detail ?? "", errorMessage: outcome === "failed" ? detail ?? null : null },
      }).catch(() => {});
    }
    setState(outcome === "failed" ? "error" : "idle");
  }, []);

  useEffect(() => () => void end("canceled", "Left the page"), [end]);

  async function start() {
    if (!settings) return;
    setError(null);
    setLines([]);
    setElapsed(0);
    setMuted(false);
    const lang = resolveLanguage(settings.defaultLanguage);
    try {
      setState("connecting");
      const { session: s } = await api<{ session: CallSession }>("/api/sessions", {
        method: "POST",
        json: { type: "browser_voice", contactId: contactId || null, language: lang.code },
      });
      session.current = s;
      const token = await api<{ provider: string } & Partial<RealtimeToken>>("/api/voice/realtime-token", {
        method: "POST",
        json: { sessionId: s.id },
      });
      const callbacks = {
        onState: setState,
        onTranscript,
        onAgentSpeaking: setAgentSpeaking,
        onUserSpeaking: setUserSpeaking,
        onLevel: setLevel,
        onError: (m: string) => setError(m),
        onEnd: (reason: string) => void end(reason === "connection_failed" ? "failed" : "completed", reason === "agent_ended" ? "Agent ended the conversation" : reason),
      };
      const eng: VoiceEngine =
        token.provider === "demo" || !token.clientSecret
          ? new DemoSpeechEngine({ lang: lang.speechTag, greeting: lang.greeting(settings.agentName) }, callbacks)
          : new OpenAIRealtimeEngine(token as RealtimeToken, callbacks);
      engine.current = eng;
      setEngineLabel(eng.label);
      setIsDemo(eng.isDemo);
      await eng.start();
      const started = Date.now();
      timer.current = window.setInterval(() => {
        const sec = Math.floor((Date.now() - started) / 1000);
        setElapsed(sec);
        if (sec >= settings.maxCallDurationSec) void end("completed", "Maximum duration reached");
      }, 500);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Could not start the voice session";
      setError(msg);
      await end("failed", msg);
    }
  }

  function toggleMute() {
    const next = !muted;
    setMuted(next);
    engine.current?.setMuted(next);
  }

  function sendTyped(e: React.FormEvent) {
    e.preventDefault();
    const t = typed.trim();
    if (!t || !engine.current) return;
    engine.current.sendText(t);
    setTyped("");
  }

  const active = state === "live" || state === "connecting" || state === "requesting_mic";
  const max = settings?.maxCallDurationSec ?? 300;
  const aiConfigured = status?.ai.configured;

  return (
    <>
      <PageHeader title="Voice agent" description="Talk to the agent in your browser. This is never a telephone call and costs nothing on the phone network." />

      {status && !aiConfigured && (
        <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900" data-testid="demo-voice-notice">
          <strong>Demo voice mode.</strong> No AI provider is configured, so replies are <em>mock, rule-based responses</em> spoken with your
          browser&apos;s built-in speech engine. To talk to a real AI model, add an OpenAI API key — see the{" "}
          <Link href="/setup" className="underline">setup guide</Link>.
          {!canRecognize && " Your browser has no speech recognition (try Chrome or Edge); you can type messages instead."}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="card space-y-5">
          <div>
            <label className="label" htmlFor="agent-contact">Contact context (optional)</label>
            <select id="agent-contact" className="input" value={contactId} onChange={(e) => setContactId(e.target.value)} disabled={active}>
              <option value="">No contact — general test</option>
              {contacts.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div className="text-sm text-slate-500">
            Language: <strong className="text-slate-700">{settings ? LANGUAGES[settings.defaultLanguage].label : "…"}</strong>
            <span className="ml-1 text-xs">(Telugu & Hindi planned)</span>
          </div>

          <div className="flex flex-col items-center gap-4 py-4">
            <div
              className={`relative flex h-32 w-32 items-center justify-center rounded-full transition ${
                state === "live" ? (agentSpeaking ? "bg-indigo-100" : "bg-emerald-50") : "bg-slate-100"
              }`}
              aria-hidden
            >
              <div
                className={`absolute rounded-full ${agentSpeaking ? "bg-indigo-400/40" : "bg-emerald-400/40"}`}
                style={{ width: `${64 + level * 64}px`, height: `${64 + level * 64}px`, transition: "width 80ms, height 80ms" }}
              />
              <div className={`relative h-16 w-16 rounded-full ${state === "live" ? (agentSpeaking ? "bg-indigo-600" : "bg-emerald-600") : "bg-slate-400"}`} />
            </div>
            <div className="text-center" data-testid="voice-state" aria-live="polite">
              <div className="text-sm font-medium text-slate-800">{STATE_LABEL[state]}</div>
              {state === "live" && (
                <div className="text-xs text-slate-500">
                  {muted ? "Microphone muted" : agentSpeaking ? "Agent speaking…" : userSpeaking ? "Listening to you…" : "Listening"} ·{" "}
                  {Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, "0")} / {Math.floor(max / 60)}:{String(max % 60).padStart(2, "0")}
                </div>
              )}
            </div>
            {engineLabel && state !== "idle" && <Badge color={isDemo ? "amber" : "blue"}>{engineLabel}</Badge>}
          </div>

          <div className="flex gap-2">
            {!active ? (
              <button className="btn-primary flex-1" onClick={start} disabled={!settings} data-testid="start-voice">
                Start conversation
              </button>
            ) : (
              <>
                <button className="btn-secondary flex-1" onClick={toggleMute} disabled={state !== "live"} aria-pressed={muted}>
                  {muted ? "Unmute" : "Mute"}
                </button>
                <button className="btn-danger flex-1" onClick={() => void end("completed", "Ended by user")} data-testid="stop-voice">
                  End
                </button>
              </>
            )}
          </div>
          <ErrorBanner message={error} onDismiss={() => setError(null)} />
        </div>

        <div className="card flex min-h-[28rem] flex-col lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">Live transcript</h2>
            {isDemo && lines.length > 0 && <Badge color="amber">Demo – mock AI</Badge>}
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto rounded-lg bg-slate-50 p-4" data-testid="live-transcript">
            {lines.length === 0 ? (
              <p className="text-sm text-slate-400">The conversation transcript will appear here.</p>
            ) : (
              lines.map((l) => (
                <div key={l.id} className={`flex ${l.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${
                      l.role === "user" ? "bg-indigo-600 text-white" : "border border-slate-200 bg-white text-slate-800"
                    } ${l.final ? "" : "opacity-60"}`}
                  >
                    {l.text}
                  </div>
                </div>
              ))
            )}
            <div ref={transcriptEnd} />
          </div>
          <form onSubmit={sendTyped} className="mt-3 flex gap-2">
            <input
              className="input"
              placeholder={state === "live" ? "Type a message instead of speaking…" : "Start a conversation to type"}
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              disabled={state !== "live"}
              aria-label="Type a message"
            />
            <button className="btn-secondary" disabled={state !== "live" || !typed.trim()}>
              Send
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
