"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useApp } from "@/components/app-context";
import { ErrorBanner, PageHeader, Spinner } from "@/components/ui";
import { api, fieldErrors } from "@/lib/client/api";
import { LANGUAGES } from "@/lib/languages";
import type { AppSettings } from "@/lib/types";

export default function SettingsPage() {
  const { status, settings, setSettings } = useApp();
  const [form, setForm] = useState<AppSettings | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- seed form from loaded settings
    if (settings && !form) setForm(settings);
  }, [settings, form]);

  if (!form || !status) return <Spinner />;
  const set = <K extends keyof AppSettings>(k: K, v: AppSettings[K]) => {
    setSaved(false);
    setForm((f) => (f ? { ...f, [k]: v } : f));
  };
  const liveAllowed = status.dataMode === "supabase" && status.telecom.liveCallsEnabledByServer;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setErrors({});
    try {
      const res = await api<{ settings: AppSettings }>("/api/settings", { method: "PUT", json: form });
      setSettings(res.settings);
      setForm(res.settings);
      setSaved(true);
    } catch (err) {
      setErrors(fieldErrors(err));
      setError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <PageHeader title="Settings" description="Agent behaviour, safety and privacy. Secrets are configured as server environment variables, never here." />
      <form onSubmit={save} className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="card space-y-4">
            <h2 className="font-semibold">Call mode</h2>
            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                className="mt-1"
                checked={form.testMode}
                onChange={(e) => set("testMode", e.target.checked)}
                disabled={!liveAllowed}
                data-testid="test-mode-toggle"
              />
              <span>
                <span className="font-medium">Test mode</span>
                <span className="block text-sm text-slate-500">
                  When on, no real telephone call can be placed. Simulated calls and browser voice still work.
                </span>
                {!liveAllowed && (
                  <span className="mt-1 block text-xs text-amber-700" data-testid="test-mode-locked">
                    Locked on: {status.dataMode !== "supabase" ? "demo data mode (configure Supabase + sign in)" : "LIVE_CALLS_ENABLED is not 'true' on the server"}.
                  </span>
                )}
              </span>
            </label>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="s-lang">Default language</label>
                <select id="s-lang" className="input" value={form.defaultLanguage} onChange={(e) => set("defaultLanguage", e.target.value as AppSettings["defaultLanguage"])}>
                  {Object.values(LANGUAGES).map((l) => (
                    <option key={l.code} value={l.code} disabled={!l.enabled}>
                      {l.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="s-max">Maximum call duration (seconds)</label>
                <input
                  id="s-max"
                  type="number"
                  min={30}
                  max={1800}
                  className="input"
                  value={form.maxCallDurationSec}
                  onChange={(e) => set("maxCallDurationSec", Number(e.target.value))}
                />
                {errors.maxCallDurationSec && <p className="mt-1 text-xs text-red-600">{errors.maxCallDurationSec}</p>}
              </div>
              <div>
                <label className="label" htmlFor="s-agent">Agent name</label>
                <input id="s-agent" className="input" value={form.agentName} onChange={(e) => set("agentName", e.target.value)} />
              </div>
            </div>
          </section>

          <section className="card space-y-4">
            <h2 className="font-semibold">Consent & disclosure</h2>
            <div>
              <label className="label" htmlFor="s-disc">AI disclosure (spoken at the start of every telephone call)</label>
              <textarea id="s-disc" rows={3} className="input" value={form.disclosureMessage} onChange={(e) => set("disclosureMessage", e.target.value)} />
              {errors.disclosureMessage && <p className="mt-1 text-xs text-red-600">{errors.disclosureMessage}</p>}
            </div>
            <ul className="list-disc space-y-1 pl-5 text-sm text-slate-600">
              <li>Live calls are only allowed to contacts whose consent is <strong>granted</strong> with a recorded source.</li>
              <li>Saying “stop”, “opt out” or “don’t call” ends the call and marks the contact do-not-call.</li>
              <li>The agent always identifies itself as an AI.</li>
            </ul>
          </section>

          <section className="card space-y-4">
            <h2 className="font-semibold">Privacy</h2>
            <label className="flex items-center gap-3 text-sm">
              <input type="checkbox" checked={form.storeTranscripts} onChange={(e) => set("storeTranscripts", e.target.checked)} />
              Store conversation transcripts
            </label>
            <div className="max-w-xs">
              <label className="label" htmlFor="s-ret">Transcript retention (days)</label>
              <input
                id="s-ret"
                type="number"
                min={1}
                max={365}
                className="input"
                value={form.transcriptRetentionDays}
                onChange={(e) => set("transcriptRetentionDays", Number(e.target.value))}
              />
            </div>
          </section>

          <ErrorBanner message={error} />
          <div className="flex items-center gap-3">
            <button className="btn-primary" disabled={saving}>
              {saving ? "Saving…" : "Save settings"}
            </button>
            {saved && <span className="text-sm text-emerald-700">Saved.</span>}
          </div>
        </div>

        <aside className="space-y-6">
          <section className="card space-y-3 text-sm">
            <h2 className="font-semibold">AI provider</h2>
            <StatusLine ok={status.ai.configured} text={status.ai.configured ? `OpenAI Realtime · ${status.ai.realtimeModel}` : "Not configured — demo mock responses"} />
            {!status.ai.configured && <p className="text-slate-500">Set AI_PROVIDER=openai and OPENAI_API_KEY on the server.</p>}
          </section>
          <section className="card space-y-3 text-sm">
            <h2 className="font-semibold">Telecom provider</h2>
            <StatusLine ok={status.telecom.configured} text={status.telecom.configured ? `Twilio · caller ID ${status.telecom.callerIdMasked}` : "Not configured"} />
            <StatusLine ok={status.telecom.liveCallsEnabledByServer} text={`Server kill switch: ${status.telecom.liveCallsEnabledByServer ? "live calls allowed" : "live calls disabled"}`} />
            <StatusLine ok={status.telecom.webhooksReachable} text={status.telecom.webhooksReachable ? "Public https webhook URL" : "APP_BASE_URL is not https"} />
            <StatusLine ok={status.telecom.webhookServiceRoleConfigured} text="Webhook database access" />
            <p className="text-slate-500">Allowed countries: {status.telecom.allowedCountries.join(", ") || "none"}</p>
          </section>
          <Link href="/setup" className="block text-sm text-indigo-600 hover:underline">
            How to configure providers →
          </Link>
        </aside>
      </form>
    </>
  );
}

function StatusLine({ ok, text }: { ok: boolean; text: string }) {
  return (
    <div className="flex items-start gap-2">
      <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${ok ? "bg-emerald-500" : "bg-slate-300"}`} />
      <span className={ok ? "text-slate-800" : "text-slate-500"}>{text}</span>
    </div>
  );
}
