"use client";

import { useEffect, useMemo, useState } from "react";
import { api, formatDate, formatDuration } from "@/lib/client/api";
import type { CallSession, SessionType, TranscriptEntry } from "@/lib/types";
import { ErrorBanner, Modal, PageHeader, SessionTypeBadge, Spinner, StatusBadge } from "@/components/ui";

interface Detail {
  session: CallSession;
  transcript: TranscriptEntry[] | null;
  transcriptPolicy: { stored: boolean; retentionDays: number };
}

export default function HistoryPage() {
  const [sessions, setSessions] = useState<CallSession[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [type, setType] = useState<"" | SessionType>("");
  const [selected, setSelected] = useState<CallSession | null>(null);
  const [detail, setDetail] = useState<Detail | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  useEffect(() => {
    api<{ sessions: CallSession[] }>("/api/sessions")
      .then((r) => setSessions(r.sessions))
      .catch((e: Error) => setError(e.message));
  }, []);

  const filtered = useMemo(() => (sessions ?? []).filter((s) => !type || s.type === type), [sessions, type]);

  function open(s: CallSession) {
    setSelected(s);
    setDetail(null);
  }

  async function revealTranscript() {
    if (!selected) return;
    setLoadingDetail(true);
    try {
      setDetail(await api<Detail>(`/api/sessions/${selected.id}?transcript=1`));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load transcript");
    } finally {
      setLoadingDetail(false);
    }
  }

  return (
    <>
      <PageHeader
        title="Call history"
        description="Every simulated call, browser voice session and telephone call."
        actions={
          <select className="input w-auto" value={type} onChange={(e) => setType(e.target.value as typeof type)} aria-label="Filter by type">
            <option value="">All types</option>
            <option value="simulated">Simulated</option>
            <option value="browser_voice">Browser voice</option>
            <option value="telephone">Telephone</option>
          </select>
        }
      />
      <ErrorBanner message={error} onDismiss={() => setError(null)} />
      <div className="card mt-4 p-0">
        {!sessions ? (
          <div className="px-4">
            <Spinner />
          </div>
        ) : filtered.length === 0 ? (
          <p className="p-6 text-sm text-slate-500">No sessions yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-100">
              <thead className="bg-slate-50">
                <tr>
                  <th className="th">Session</th>
                  <th className="th">Contact</th>
                  <th className="th">Type</th>
                  <th className="th">Started</th>
                  <th className="th">Duration</th>
                  <th className="th">Outcome</th>
                  <th className="th" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((s) => (
                  <tr key={s.id} data-testid="history-row">
                    <td className="td font-mono text-xs text-slate-500" title={s.id}>
                      {s.id.slice(0, 8)}
                    </td>
                    <td className="td">{s.contactName ?? "—"}</td>
                    <td className="td">
                      <SessionTypeBadge type={s.type} isDemo={s.isDemo} />
                    </td>
                    <td className="td whitespace-nowrap">{formatDate(s.startedAt)}</td>
                    <td className="td tabular-nums">{formatDuration(s.durationSec)}</td>
                    <td className="td">
                      <div className="flex items-center gap-2">
                        <StatusBadge status={s.status} />
                        <span className="max-w-[16rem] truncate text-slate-500">{s.outcome}</span>
                      </div>
                    </td>
                    <td className="td text-right">
                      <button className="btn-ghost px-2 py-1" onClick={() => open(s)}>
                        Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Session details" wide>
        {selected && (
          <div className="space-y-4 text-sm">
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-3">
              <Field label="Session ID" value={<span className="font-mono text-xs">{selected.id}</span>} />
              <Field label="Type" value={<SessionTypeBadge type={selected.type} isDemo={selected.isDemo} />} />
              <Field label="Status" value={<StatusBadge status={selected.status} />} />
              <Field label="Contact" value={selected.contactName ?? "—"} />
              <Field label="Started" value={formatDate(selected.startedAt)} />
              <Field label="Duration" value={formatDuration(selected.durationSec)} />
              <Field label="Provider" value={selected.provider} />
              <Field label="Language" value={selected.language} />
              <Field label="Outcome" value={selected.outcome || "—"} />
            </dl>
            {selected.type === "simulated" && (
              <p className="rounded-lg bg-violet-50 px-3 py-2 text-violet-900">Simulated — no real phone was dialed.</p>
            )}
            {selected.errorMessage && <ErrorBanner message={selected.errorMessage} />}
            <div className="border-t border-slate-100 pt-4">
              {!detail ? (
                <button className="btn-secondary" onClick={revealTranscript} disabled={loadingDetail} data-testid="reveal-transcript">
                  {loadingDetail ? "Loading…" : "Show transcript"}
                </button>
              ) : !detail.transcriptPolicy.stored ? (
                <p className="text-slate-500">Transcript storage is turned off in Settings.</p>
              ) : !detail.transcript?.length ? (
                <p className="text-slate-500">No transcript available (it may have passed the {detail.transcriptPolicy.retentionDays}-day retention period).</p>
              ) : (
                <div className="max-h-96 space-y-2 overflow-y-auto rounded-lg bg-slate-50 p-3" data-testid="history-transcript">
                  {detail.transcript.map((t) => (
                    <div key={t.id} className={t.role === "system" ? "text-center text-xs italic text-slate-500" : ""}>
                      {t.role !== "system" && (
                        <span className={`mr-2 font-semibold ${t.role === "agent" ? "text-indigo-700" : "text-slate-700"}`}>
                          {t.role === "agent" ? "Agent" : selected.type === "simulated" ? "Contact (simulated)" : "User"}:
                        </span>
                      )}
                      {t.text}
                    </div>
                  ))}
                  <p className="pt-2 text-xs text-slate-400">Transcripts are deleted after {detail.transcriptPolicy.retentionDays} days.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs text-slate-500">{label}</dt>
      <dd className="mt-0.5 text-slate-800">{value}</dd>
    </div>
  );
}
