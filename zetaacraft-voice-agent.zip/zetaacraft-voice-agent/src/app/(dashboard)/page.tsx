"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useApp } from "@/components/app-context";
import { ErrorBanner, PageHeader, SessionTypeBadge, Spinner, StatusBadge } from "@/components/ui";
import { api, formatDate, formatDuration } from "@/lib/client/api";
import type { CallSession, Metrics } from "@/lib/types";

function Stat({ label, value, hint, testId }: { label: string; value: string | number; hint?: string; testId?: string }) {
  return (
    <div className="card" data-testid={testId}>
      <div className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-2 text-3xl font-semibold tabular-nums text-slate-900">{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-400">{hint}</div>}
    </div>
  );
}

export default function OverviewPage() {
  const { status, settings } = useApp();
  const [data, setData] = useState<{ metrics: Metrics; recent: CallSession[] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<{ metrics: Metrics; recent: CallSession[] }>("/api/metrics")
      .then(setData)
      .catch((e: Error) => setError(e.message));
  }, []);

  const live = settings?.testMode === false;
  return (
    <>
      <PageHeader
        title="Overview"
        description="Activity across simulated calls, browser voice sessions and telephone calls."
        actions={
          <>
            <Link href="/agent" className="btn-primary">
              Start voice test
            </Link>
            <Link href="/contacts" className="btn-secondary">
              Simulate a call
            </Link>
          </>
        }
      />
      <ErrorBanner message={error} />
      {!data && !error ? (
        <Spinner />
      ) : data ? (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <Stat label="Test sessions" value={data.metrics.totalTestSessions} hint="Simulated + browser voice" testId="stat-test-sessions" />
            <Stat label="Completed calls" value={data.metrics.completedCalls} testId="stat-completed" />
            <Stat label="Failed sessions" value={data.metrics.failedSessions} testId="stat-failed" />
            <Stat label="Total duration" value={formatDuration(data.metrics.totalDurationSec)} testId="stat-duration" />
            <div className="card" data-testid="stat-mode">
              <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Mode</div>
              <div className={`mt-2 text-2xl font-semibold ${live ? "text-red-600" : "text-amber-600"}`}>{live ? "Live" : "Test"}</div>
              <div className="mt-1 text-xs text-slate-400">
                {live ? "Real calls possible" : "No real calls"} · {data.metrics.byType.telephone} phone calls
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-3">
            <div className="card lg:col-span-2">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="font-semibold">Recent sessions</h2>
                <Link href="/history" className="text-sm text-indigo-600 hover:underline">
                  View all
                </Link>
              </div>
              {data.recent.length === 0 ? (
                <p className="py-6 text-sm text-slate-500">
                  No sessions yet. Run a <Link className="text-indigo-600 underline" href="/contacts">simulated call</Link> or start a{" "}
                  <Link className="text-indigo-600 underline" href="/agent">browser voice test</Link>.
                </p>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {data.recent.map((s) => (
                    <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
                      <div className="flex items-center gap-2">
                        <SessionTypeBadge type={s.type} isDemo={s.isDemo} />
                        <span className="text-slate-800">{s.contactName ?? "No contact"}</span>
                      </div>
                      <div className="flex items-center gap-3 text-slate-500">
                        <span>{formatDate(s.startedAt)}</span>
                        <StatusBadge status={s.status} />
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="card">
              <h2 className="mb-3 font-semibold">Configuration</h2>
              {status && (
                <ul className="space-y-2 text-sm">
                  <ConfigRow label="Data" ok={status.dataMode === "supabase"} okText="Supabase" offText="Local demo store" />
                  <ConfigRow label="AI provider" ok={status.ai.configured} okText={`OpenAI (${status.ai.realtimeModel})`} offText="Demo / mock" />
                  <ConfigRow label="Telecom" ok={status.telecom.configured} okText="Twilio configured" offText="Not configured" />
                  <ConfigRow label="Live calls (server)" ok={status.telecom.liveCallsEnabledByServer} okText="Allowed" offText="Disabled" />
                </ul>
              )}
              <Link href="/setup" className="mt-4 inline-block text-sm text-indigo-600 hover:underline">
                Setup guide →
              </Link>
            </div>
          </div>
        </>
      ) : null}
    </>
  );
}

function ConfigRow({ label, ok, okText, offText }: { label: string; ok: boolean; okText: string; offText: string }) {
  return (
    <li className="flex items-center justify-between gap-2">
      <span className="text-slate-500">{label}</span>
      <span className={`flex items-center gap-1.5 ${ok ? "text-emerald-700" : "text-slate-500"}`}>
        <span className={`h-2 w-2 rounded-full ${ok ? "bg-emerald-500" : "bg-slate-300"}`} />
        {ok ? okText : offText}
      </span>
    </li>
  );
}
