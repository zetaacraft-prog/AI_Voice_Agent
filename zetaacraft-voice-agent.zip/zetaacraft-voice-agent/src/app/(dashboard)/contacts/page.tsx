"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "@/lib/client/api";
import { maskPhone } from "@/lib/phone";
import type { Contact } from "@/lib/types";
import { ConsentBadge, ContactStatusBadge, ErrorBanner, Modal, PageHeader, Spinner } from "@/components/ui";
import { ContactForm } from "./contact-form";
import { SimulateDialog } from "./simulate-dialog";
import { LiveCallDialog } from "./live-call-dialog";

type Dialog = { kind: "add" } | { kind: "edit" | "simulate" | "live" | "delete"; contact: Contact } | null;

export default function ContactsPage() {
  const [contacts, setContacts] = useState<Contact[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [dialog, setDialog] = useState<Dialog>(null);
  const [reveal, setReveal] = useState<Record<string, boolean>>({});

  const load = useCallback(async () => {
    try {
      setContacts((await api<{ contacts: Contact[] }>("/api/contacts")).contacts);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load contacts");
    }
  }, []);
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial data load
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!contacts) return [];
    return q ? contacts.filter((c) => `${c.name} ${c.phone} ${c.purpose} ${c.country}`.toLowerCase().includes(q)) : contacts;
  }, [contacts, query]);

  async function remove(c: Contact) {
    try {
      await api(`/api/contacts/${c.id}`, { method: "DELETE" });
      setDialog(null);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Delete failed");
    }
  }

  return (
    <>
      <PageHeader
        title="Contacts"
        description="Only contacts with granted consent can receive live calls. Anyone can be used for simulated calls — nobody is dialed."
        actions={
          <button className="btn-primary" onClick={() => setDialog({ kind: "add" })}>
            + Add contact
          </button>
        }
      />
      <ErrorBanner message={error} onDismiss={() => setError(null)} />
      <div className="card mt-4 p-0">
        <div className="border-b border-slate-100 p-3">
          <input className="input max-w-xs" placeholder="Search contacts…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search contacts" />
        </div>
        {!contacts ? (
          <div className="px-4">
            <Spinner />
          </div>
        ) : filtered.length === 0 ? (
          <p className="p-6 text-sm text-slate-500">{contacts.length ? "No contacts match your search." : "No contacts yet. Add your first contact."}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-100">
              <thead className="bg-slate-50">
                <tr>
                  <th className="th">Name</th>
                  <th className="th">Phone</th>
                  <th className="th">Purpose</th>
                  <th className="th">Consent</th>
                  <th className="th">Status</th>
                  <th className="th text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((c) => (
                  <tr key={c.id} data-testid="contact-row">
                    <td className="td">
                      <div className="font-medium text-slate-900">{c.name}</div>
                      {c.notes && <div className="max-w-xs truncate text-xs text-slate-400">{c.notes}</div>}
                    </td>
                    <td className="td whitespace-nowrap font-mono text-xs">
                      <button
                        className="hover:text-indigo-600"
                        title={reveal[c.id] ? "Hide" : "Reveal full number"}
                        onClick={() => setReveal((r) => ({ ...r, [c.id]: !r[c.id] }))}
                      >
                        {reveal[c.id] ? c.phone : maskPhone(c.phone)}
                      </button>
                      <span className="ml-2 text-slate-400">{c.country}</span>
                    </td>
                    <td className="td max-w-[14rem] truncate">{c.purpose || "—"}</td>
                    <td className="td">
                      <ConsentBadge status={c.consentStatus} />
                      {c.consentSource && <div className="mt-0.5 max-w-[12rem] truncate text-xs text-slate-400">{c.consentSource}</div>}
                    </td>
                    <td className="td">
                      <ContactStatusBadge status={c.status} />
                    </td>
                    <td className="td whitespace-nowrap text-right">
                      <button className="btn-ghost px-2 py-1" onClick={() => setDialog({ kind: "simulate", contact: c })}>
                        Simulate
                      </button>
                      <button className="btn-ghost px-2 py-1 text-red-600" onClick={() => setDialog({ kind: "live", contact: c })}>
                        Live call
                      </button>
                      <button className="btn-ghost px-2 py-1" onClick={() => setDialog({ kind: "edit", contact: c })}>
                        Edit
                      </button>
                      <button className="btn-ghost px-2 py-1 text-slate-400" onClick={() => setDialog({ kind: "delete", contact: c })} aria-label={`Delete ${c.name}`}>
                        ✕
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal open={dialog?.kind === "add"} onClose={() => setDialog(null)} title="Add contact">
        <ContactForm
          onSaved={() => {
            setDialog(null);
            void load();
          }}
        />
      </Modal>
      {dialog && dialog.kind !== "add" && (
        <Modal
          open
          wide={dialog.kind === "simulate"}
          onClose={() => {
            setDialog(null);
            void load();
          }}
          title={
            dialog.kind === "edit"
              ? `Edit ${dialog.contact.name}`
              : dialog.kind === "simulate"
                ? `Simulated call · ${dialog.contact.name}`
                : dialog.kind === "live"
                  ? `Live call · ${dialog.contact.name}`
                  : "Delete contact"
          }
        >
          {dialog.kind === "edit" && (
            <ContactForm
              contact={dialog.contact}
              onSaved={() => {
                setDialog(null);
                void load();
              }}
            />
          )}
          {dialog.kind === "simulate" && <SimulateDialog contact={dialog.contact} onDone={load} />}
          {dialog.kind === "live" && <LiveCallDialog contact={dialog.contact} onPlaced={load} />}
          {dialog.kind === "delete" && (
            <div className="space-y-4 text-sm">
              <p>
                Delete <strong>{dialog.contact.name}</strong>? Call history is kept but unlinked from this contact.
              </p>
              <div className="flex justify-end gap-2">
                <button className="btn-secondary" onClick={() => setDialog(null)}>
                  Cancel
                </button>
                <button className="btn-danger" onClick={() => remove(dialog.contact)}>
                  Delete
                </button>
              </div>
            </div>
          )}
        </Modal>
      )}
    </>
  );
}
