"use client";

import { useEffect, useState } from "react";
import { api, ApiError } from "@/lib/client/api";
import type { GateReason, GateResult } from "@/lib/safety/live-call-gate";
import type { CallSession, Contact } from "@/lib/types";
import { ErrorBanner, Spinner } from "@/components/ui";

/** Real telephone call. Shows every blocking safety check; requires explicit confirmation. */
export function LiveCallDialog({ contact, onPlaced }: { contact: Contact; onPlaced: () => void }) {
  const [gate, setGate] = useState<GateResult | null>(null);
  const [last4, setLast4] = useState("");
  const [ack, setAck] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reasons, setReasons] = useState<GateReason[]>([]);
  const [placed, setPlaced] = useState<CallSession | null>(null);

  useEffect(() => {
    api<GateResult>("/api/calls/live/check", { method: "POST", json: { contactId: contact.id } })
      .then(setGate)
      .catch((e: Error) => setError(e.message));
  }, [contact.id]);

  async function place() {
    setPlacing(true);
    setError(null);
    setReasons([]);
    try {
      const res = await api<{ session: CallSession }>("/api/calls/live", {
        method: "POST",
        json: { contactId: contact.id, confirmLast4: last4, acknowledgedCharges: ack },
      });
      setPlaced(res.session);
      onPlaced();
    } catch (e) {
      if (e instanceof ApiError && Array.isArray(e.body.reasons)) setReasons(e.body.reasons as GateReason[]);
      setError(e instanceof Error ? e.message : "Call failed");
    } finally {
      setPlacing(false);
    }
  }

  if (!gate && !error) return <Spinner label="Checking safety requirements…" />;

  if (placed) {
    return (
      <div className="space-y-3 text-sm">
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-900">
          Call request accepted by the telecom provider. Status updates and the transcript will appear in Call history.
        </div>
        <p className="text-slate-500">Session {placed.id}</p>
      </div>
    );
  }

  const blocking = gate?.reasons ?? [];
  return (
    <div className="space-y-4 text-sm">
      <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-red-900">
        <strong>Real telephone call.</strong> This dials {contact.name} on the public phone network and is billed by your telecom provider.
        International rates may apply.
      </div>
      <ErrorBanner message={error} />
      {(reasons.length ? reasons : blocking).length > 0 ? (
        <div data-testid="gate-reasons">
          <p className="mb-2 font-medium text-slate-800">Live calling is blocked:</p>
          <ul className="list-disc space-y-1 pl-5 text-slate-700">
            {(reasons.length ? reasons : blocking).map((r) => (
              <li key={r.code}>
                {r.message} <span className="font-mono text-xs text-slate-400">{r.code}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-slate-500">Use “Simulate” to test this workflow for free.</p>
        </div>
      ) : (
        <>
          <div>
            <label className="label" htmlFor="last4">
              Type the last 4 digits of {contact.name}&apos;s number to confirm
            </label>
            <input
              id="last4"
              className="input font-mono"
              inputMode="numeric"
              maxLength={4}
              value={last4}
              onChange={(e) => setLast4(e.target.value.replace(/\D/g, ""))}
            />
          </div>
          <label className="flex items-start gap-2">
            <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="mt-0.5" />
            <span>I understand this is a real, billed call, the contact has consented, and the AI disclosure will be played first.</span>
          </label>
          <div className="flex justify-end">
            <button className="btn-danger" onClick={place} disabled={placing || last4.length !== 4 || !ack}>
              {placing ? "Placing call…" : "Place real call"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
