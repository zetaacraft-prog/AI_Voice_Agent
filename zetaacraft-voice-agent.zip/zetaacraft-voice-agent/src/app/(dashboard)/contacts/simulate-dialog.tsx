"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/client/api";
import type { CallSession, Contact, TranscriptRole } from "@/lib/types";
import { ErrorBanner, StatusBadge } from "@/components/ui";

type Line = { role: TranscriptRole; text: string; offsetSec: number };
const SCENARIOS = [
  { value: "", label: "Random outcome" },
  { value: "interested", label: "Interested" },
  { value: "callback", label: "Asks for callback" },
  { value: "not_interested", label: "Not interested" },
  { value: "no_answer", label: "No answer" },
  { value: "opt_out", label: "Opts out (marks do-not-call)" },
];

export function SimulateDialog({ contact, onDone }: { contact: Contact; onDone: () => void }) {
  const [scenario, setScenario] = useState("");
  const [running, setRunning] = useState(false);
  const [shown, setShown] = useState<Line[]>([]);
  const [result, setResult] = useState<CallSession | null>(null);
  const [error, setError] = useState<string | null>(null);
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  async function run() {
    setRunning(true);
    setShown([]);
    setResult(null);
    setError(null);
    try {
      const res = await api<{ session: CallSession; lines: Line[] }>("/api/calls/simulate", {
        method: "POST",
        json: { contactId: contact.id, ...(scenario ? { scenario } : {}) },
      });
      // Replay the scripted transcript quickly for a realistic feel.
      res.lines.forEach((line, i) => {
        timers.current.push(window.setTimeout(() => setShown((s) => [...s, line]), i * 450));
      });
      timers.current.push(
        window.setTimeout(() => {
          setResult(res.session);
          setRunning(false);
          onDone();
        }, res.lines.length * 450),
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Simulation failed");
      setRunning(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-violet-200 bg-violet-50 px-4 py-3 text-sm text-violet-900">
        <strong>Simulated call.</strong> Nothing is dialed and {contact.name} will not be contacted. Both sides of the conversation are scripted
        for testing the workflow.
      </div>
      <div className="flex flex-wrap items-end gap-2">
        <div className="flex-1">
          <label className="label" htmlFor="sim-scenario">Scenario</label>
          <select id="sim-scenario" className="input" value={scenario} onChange={(e) => setScenario(e.target.value)} disabled={running}>
            {SCENARIOS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        </div>
        <button className="btn-primary" onClick={run} disabled={running}>
          {running ? "Simulating…" : result ? "Run again" : "Start simulated call"}
        </button>
      </div>
      <ErrorBanner message={error} />
      {shown.length > 0 && (
        <div className="max-h-80 space-y-2 overflow-y-auto rounded-lg border border-slate-200 bg-slate-50 p-3" data-testid="sim-transcript">
          {shown.map((l, i) => (
            <div key={i} className={`text-sm ${l.role === "system" ? "text-center text-xs italic text-slate-500" : ""}`}>
              {l.role !== "system" && (
                <span className={`mr-2 font-semibold ${l.role === "agent" ? "text-indigo-700" : "text-slate-700"}`}>
                  {l.role === "agent" ? "Agent" : "Contact (simulated)"}:
                </span>
              )}
              {l.text}
            </div>
          ))}
        </div>
      )}
      {result && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-sm" data-testid="sim-result">
          <span className="flex items-center gap-2">
            <StatusBadge status={result.status} /> {result.outcome}
          </span>
          <Link className="text-indigo-600 hover:underline" href="/history">
            View in call history →
          </Link>
        </div>
      )}
    </div>
  );
}
