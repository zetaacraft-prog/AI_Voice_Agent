"use client";

import { useState } from "react";
import { api, fieldErrors } from "@/lib/client/api";
import type { Contact } from "@/lib/types";
import { ErrorBanner } from "@/components/ui";

type FormState = Pick<Contact, "name" | "phone" | "country" | "purpose" | "consentStatus" | "consentSource" | "notes" | "status">;

const empty: FormState = {
  name: "",
  phone: "",
  country: "",
  purpose: "",
  consentStatus: "pending",
  consentSource: "",
  notes: "",
  status: "active",
};

export function ContactForm({ contact, onSaved }: { contact?: Contact; onSaved: (c: Contact) => void }) {
  const [form, setForm] = useState<FormState>(contact ? { ...contact } : empty);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setErrors({});
    setError(null);
    try {
      const payload = { ...form, country: form.country || undefined };
      const res = contact
        ? await api<{ contact: Contact }>(`/api/contacts/${contact.id}`, { method: "PUT", json: payload })
        : await api<{ contact: Contact }>("/api/contacts", { method: "POST", json: payload });
      onSaved(res.contact);
    } catch (err) {
      const fe = fieldErrors(err);
      setErrors(fe);
      if (!Object.keys(fe).length) setError(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  const err = (k: string) => errors[k] && <p className="mt-1 text-xs text-red-600">{errors[k]}</p>;

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <ErrorBanner message={error} />
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="label" htmlFor="c-name">Name</label>
          <input id="c-name" className="input" value={form.name} onChange={(e) => set("name", e.target.value)} required />
          {err("name")}
        </div>
        <div>
          <label className="label" htmlFor="c-phone">Phone (with country code)</label>
          <input id="c-phone" className="input" placeholder="+91 98765 43210" value={form.phone} onChange={(e) => set("phone", e.target.value)} />
          {err("phone")}
        </div>
        <div>
          <label className="label" htmlFor="c-country">Country (ISO code, optional)</label>
          <input
            id="c-country"
            className="input uppercase"
            placeholder="Auto-detected, e.g. IN"
            maxLength={2}
            value={form.country}
            onChange={(e) => set("country", e.target.value.toUpperCase())}
          />
          {err("country")}
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="c-purpose">Purpose of contact</label>
          <input id="c-purpose" className="input" value={form.purpose} onChange={(e) => set("purpose", e.target.value)} />
          {err("purpose")}
        </div>
        <div>
          <label className="label" htmlFor="c-consent">Consent status</label>
          <select id="c-consent" className="input" value={form.consentStatus} onChange={(e) => set("consentStatus", e.target.value as FormState["consentStatus"])}>
            <option value="pending">Pending</option>
            <option value="granted">Granted</option>
            <option value="denied">Denied</option>
            <option value="revoked">Revoked</option>
          </select>
        </div>
        <div>
          <label className="label" htmlFor="c-source">Consent source</label>
          <input
            id="c-source"
            className="input"
            placeholder="e.g. Website form, 12 Oct 2026"
            value={form.consentSource}
            onChange={(e) => set("consentSource", e.target.value)}
          />
          {err("consentSource")}
        </div>
        <div>
          <label className="label" htmlFor="c-status">Contact status</label>
          <select id="c-status" className="input" value={form.status} onChange={(e) => set("status", e.target.value as FormState["status"])}>
            <option value="active">Active</option>
            <option value="do_not_call">Do not call</option>
            <option value="archived">Archived</option>
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="c-notes">Notes</label>
          <textarea id="c-notes" rows={3} className="input" value={form.notes} onChange={(e) => set("notes", e.target.value)} />
        </div>
      </div>
      <div className="flex justify-end gap-2">
        <button type="submit" className="btn-primary" disabled={saving}>
          {saving ? "Saving…" : contact ? "Save changes" : "Add contact"}
        </button>
      </div>
    </form>
  );
}
