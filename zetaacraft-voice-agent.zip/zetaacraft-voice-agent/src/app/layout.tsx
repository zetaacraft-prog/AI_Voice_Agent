import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Zetaacraft AI Voice Agent",
  description: "Trial MVP: browser voice agent, simulated calls and optional telephone calling.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
