"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { isSupabaseConfigured } from "@/lib/env";
import { createSupabaseServerClient } from "@/lib/supabase/server";

const credsSchema = z.object({
  email: z.email().max(200),
  password: z.string().min(8, "Password must be at least 8 characters").max(200),
  intent: z.enum(["signin", "signup"]),
});

export async function authAction(_prev: { error?: string; info?: string } | undefined, formData: FormData) {
  if (!isSupabaseConfigured()) return { error: "Supabase is not configured. The app is running in demo mode." };
  const parsed = credsSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Invalid input" };
  const { email, password, intent } = parsed.data;
  const db = await createSupabaseServerClient();
  if (intent === "signup") {
    const { data, error } = await db.auth.signUp({ email, password });
    if (error) return { error: error.message };
    if (!data.session) return { info: "Check your email to confirm your account, then sign in." };
  } else {
    const { error } = await db.auth.signInWithPassword({ email, password });
    if (error) return { error: "Invalid email or password." };
  }
  redirect("/");
}
