"use client";

import { useActionState } from "react";
import { authAction } from "./actions";

export function LoginForm() {
  const [state, action, pending] = useActionState(authAction, undefined);
  return (
    <form action={action} className="space-y-4">
      <label className="block text-sm">
        <span className="text-slate-700">Email</span>
        <input name="email" type="email" required autoComplete="email" className="input mt-1" />
      </label>
      <label className="block text-sm">
        <span className="text-slate-700">Password</span>
        <input name="password" type="password" required minLength={8} autoComplete="current-password" className="input mt-1" />
      </label>
      {state?.error && <p role="alert" className="text-sm text-red-600">{state.error}</p>}
      {state?.info && <p className="text-sm text-emerald-700">{state.info}</p>}
      <div className="flex gap-2">
        <button name="intent" value="signin" disabled={pending} className="btn-primary flex-1">
          Sign in
        </button>
        <button name="intent" value="signup" disabled={pending} className="btn-secondary flex-1">
          Create account
        </button>
      </div>
    </form>
  );
}
