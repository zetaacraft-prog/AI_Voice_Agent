import { redirect } from "next/navigation";
import { isSupabaseConfigured } from "@/lib/env";
import { LoginForm } from "./login-form";

export const dynamic = "force-dynamic";

export default function LoginPage() {
  if (!isSupabaseConfigured()) redirect("/");
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <div className="mb-6">
          <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600">Zetaacraft</div>
          <h1 className="text-xl font-semibold text-slate-900">AI Voice Agent</h1>
          <p className="mt-1 text-sm text-slate-500">Sign in to manage contacts and test the agent.</p>
        </div>
        <LoginForm />
      </div>
    </div>
  );
}
