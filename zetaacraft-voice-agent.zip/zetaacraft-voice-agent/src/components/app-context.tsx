"use client";

import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { PublicConfigStatus } from "@/lib/env";
import type { AppSettings } from "@/lib/types";
import { api } from "@/lib/client/api";

interface AppState {
  status: PublicConfigStatus | null;
  settings: AppSettings | null;
  error: string | null;
  refresh: () => Promise<void>;
  setSettings: (s: AppSettings) => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<PublicConfigStatus | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const [st, se] = await Promise.all([
        api<PublicConfigStatus>("/api/status"),
        api<{ settings: AppSettings }>("/api/settings"),
      ]);
      setStatus(st);
      setSettings(se.settings);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load app status");
    }
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial data load
    void refresh();
  }, [refresh]);

  return <Ctx.Provider value={{ status, settings, error, refresh, setSettings }}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp must be used inside AppProvider");
  return v;
}
