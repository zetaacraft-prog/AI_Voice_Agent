"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { AppProvider, useApp } from "./app-context";

const NAV = [
  { href: "/", label: "Overview", icon: "▦" },
  { href: "/contacts", label: "Contacts", icon: "☏" },
  { href: "/agent", label: "Voice agent", icon: "◉" },
  { href: "/history", label: "Call history", icon: "≡" },
  { href: "/settings", label: "Settings", icon: "⚙" },
  { href: "/setup", label: "Setup guide", icon: "?" },
];

function ModeBanner() {
  const { status, settings, error } = useApp();
  if (error) return <div className="bg-red-600 px-4 py-2 text-center text-sm text-white">{error}</div>;
  if (!status || !settings) return null;
  const live = settings.testMode === false;
  return (
    <div className="space-y-px">
      <div
        data-testid="mode-banner"
        className={`flex flex-wrap items-center justify-center gap-x-3 px-4 py-1.5 text-center text-xs font-medium ${
          live ? "bg-red-600 text-white" : "bg-amber-100 text-amber-900"
        }`}
      >
        {live ? (
          <span>● LIVE MODE — real, billed telephone calls can be placed to consented contacts.</span>
        ) : (
          <span>● TEST MODE — no real phone calls will be made. Simulated calls and browser voice only.</span>
        )}
        {status.dataMode === "demo" && <span className="opacity-80">· Demo data (local, no login)</span>}
        {status.ai.provider === "demo" && <span className="opacity-80">· Mock AI responses</span>}
      </div>
      {status.warnings.map((w) => (
        <div key={w} className="bg-red-50 px-4 py-1.5 text-center text-xs text-red-800">
          {w}
        </div>
      ))}
    </div>
  );
}

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const path = usePathname();
  const { status } = useApp();
  return (
    <nav className="flex h-full flex-col gap-1 p-4">
      <div className="mb-6 px-2">
        <div className="text-[11px] font-semibold uppercase tracking-widest text-indigo-600">Zetaacraft</div>
        <div className="text-base font-semibold text-slate-900">AI Voice Agent</div>
        <div className="text-[11px] text-slate-400">Trial MVP</div>
      </div>
      {NAV.map((n) => {
        const active = n.href === "/" ? path === "/" : path.startsWith(n.href);
        return (
          <Link
            key={n.href}
            href={n.href}
            onClick={onNavigate}
            className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium ${
              active ? "bg-indigo-50 text-indigo-700" : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            <span className="w-4 text-center" aria-hidden>
              {n.icon}
            </span>
            {n.label}
          </Link>
        );
      })}
      <div className="mt-auto px-2 pt-6 text-xs text-slate-400">
        {status?.dataMode === "supabase" ? (
          <form action="/api/auth/signout" method="post">
            <button className="hover:text-slate-700">Sign out</button>
          </form>
        ) : (
          <span>Demo mode · no account needed</span>
        )}
      </div>
    </nav>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <AppProvider>
      <div className="flex min-h-screen flex-col">
        <ModeBanner />
        <div className="flex flex-1">
          <aside className="hidden w-60 shrink-0 border-r border-slate-200 bg-white md:block">
            <Sidebar />
          </aside>
          {open && (
            <div className="fixed inset-0 z-40 md:hidden" onClick={() => setOpen(false)}>
              <div className="absolute inset-0 bg-slate-900/30" />
              <aside className="absolute left-0 top-0 h-full w-64 bg-white shadow-xl" onClick={(e) => e.stopPropagation()}>
                <Sidebar onNavigate={() => setOpen(false)} />
              </aside>
            </div>
          )}
          <div className="min-w-0 flex-1">
            <div className="flex items-center border-b border-slate-200 bg-white px-4 py-3 md:hidden">
              <button className="btn-ghost px-2" onClick={() => setOpen(true)} aria-label="Open menu">
                ☰
              </button>
              <span className="ml-2 text-sm font-semibold">Zetaacraft AI Voice Agent</span>
            </div>
            <main className="mx-auto max-w-6xl p-4 sm:p-6 lg:p-8">{children}</main>
          </div>
        </div>
      </div>
    </AppProvider>
  );
}
