"use client";

import { useEffect, useRef } from "react";
import type { ConsentStatus, ContactStatus, SessionStatus, SessionType } from "@/lib/types";

const tone = {
  gray: "bg-slate-50 text-slate-700 ring-slate-200",
  green: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  amber: "bg-amber-50 text-amber-800 ring-amber-200",
  red: "bg-red-50 text-red-700 ring-red-200",
  blue: "bg-sky-50 text-sky-700 ring-sky-200",
  violet: "bg-violet-50 text-violet-700 ring-violet-200",
} as const;
export type Tone = keyof typeof tone;

export function Badge({ children, color = "gray", title }: { children: React.ReactNode; color?: Tone; title?: string }) {
  return (
    <span className={`badge ${tone[color]}`} title={title}>
      {children}
    </span>
  );
}

export function SessionTypeBadge({ type, isDemo }: { type: SessionType; isDemo?: boolean }) {
  if (type === "simulated") return <Badge color="violet" title="Scripted — no real phone was dialed">Simulated</Badge>;
  if (type === "browser_voice")
    return (
      <Badge color="blue" title={isDemo ? "Browser speech + mock AI responses" : "Browser voice with real AI"}>
        Browser voice{isDemo ? " · demo" : ""}
      </Badge>
    );
  return <Badge color="red" title="Real telephone network call">Telephone</Badge>;
}

const statusTone: Record<SessionStatus, Tone> = {
  queued: "gray",
  in_progress: "blue",
  completed: "green",
  failed: "red",
  no_answer: "amber",
  busy: "amber",
  canceled: "gray",
};
export function StatusBadge({ status }: { status: SessionStatus }) {
  return <Badge color={statusTone[status]}>{status.replace("_", " ")}</Badge>;
}

const consentTone: Record<ConsentStatus, Tone> = { granted: "green", pending: "amber", denied: "red", revoked: "red" };
export function ConsentBadge({ status }: { status: ConsentStatus }) {
  return <Badge color={consentTone[status]}>consent: {status}</Badge>;
}

const contactTone: Record<ContactStatus, Tone> = { active: "green", do_not_call: "red", archived: "gray" };
export function ContactStatusBadge({ status }: { status: ContactStatus }) {
  return <Badge color={contactTone[status]}>{status.replaceAll("_", " ")}</Badge>;
}

export function ErrorBanner({ message, onDismiss }: { message: string | null; onDismiss?: () => void }) {
  if (!message) return null;
  return (
    <div role="alert" className="flex items-start justify-between gap-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
      <span>{message}</span>
      {onDismiss && (
        <button onClick={onDismiss} className="text-red-600 hover:text-red-800" aria-label="Dismiss">
          ✕
        </button>
      )}
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900">{title}</h1>
        {description && <p className="mt-1 text-sm text-slate-500">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      onClose={onClose}
      aria-label={title}
      className={`m-auto w-[calc(100%-2rem)] ${wide ? "max-w-3xl" : "max-w-lg"} rounded-2xl p-0 shadow-xl backdrop:bg-slate-900/40`}
    >
      {open && (
        <div className="p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
            <button onClick={onClose} className="btn-ghost px-2 py-1" aria-label="Close">
              ✕
            </button>
          </div>
          {children}
        </div>
      )}
    </dialog>
  );
}

export function Spinner({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 py-8 text-sm text-slate-500" role="status">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-slate-300 border-t-indigo-600" />
      {label}
    </div>
  );
}
