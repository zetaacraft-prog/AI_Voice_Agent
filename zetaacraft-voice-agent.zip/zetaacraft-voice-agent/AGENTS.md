<!-- BEGIN:nextjs-agent-rules -->

## This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

## Project notes (Zetaacraft AI Voice Agent)

- Run `npm run check` (typecheck, lint, Vitest) before finishing any change. Run `npm run test:e2e` after UI changes.
- **Safety invariant:** a real phone call may only be placed from `src/app/api/calls/live/route.ts`, after `evaluateLiveCallGate` (`src/lib/safety/live-call-gate.ts`) allows it. Never bypass or weaken the gate. Test mode must always block dialing.
- Never import `src/lib/env.ts` or anything holding secrets into client components. Secrets must never use the `NEXT_PUBLIC_` prefix.
- Demo/mock behaviour must stay visibly labelled in the UI (`isDemo`, "Simulated", "Demo – mock AI").
- This is Next.js 16: `proxy.ts` replaces middleware, and route handler `params` is a Promise.
